-- =====================
-- Van Hold Event - Server
-- =====================

-- Debug helper function
local function DebugPrint(message)
    if Config and Config.DEBUG_MODE then
        print(message)
    end
end

local TEAM_MAP = {
    police = 'Police',
    sheriff = 'Sheriff',
    ambulance = 'EMS'
}


local EventActive = false
local VanHolder = nil
local HolderTeam = nil
local EventStartTime = 0
local EventEndTime = 0 -- When the event should end (timestamp)
local EventDuration = 0 -- Event duration in seconds
local WinnerDeclared = false
local deadPlayers = {}
local CurrentEventLocation = nil -- Store current event location for syncing to new players
local CurrentEventSpawnerId = nil -- Store spawner ID for current event

-- Event Statistics
local EventStats = {
    totalEvents = 0,
    totalWins = {},
    longestHoldTime = 0,
    longestHolder = nil,
    mostWins = 0,
    mostWinsPlayer = nil
}

-- Streak System
local PlayerStreaks = {}  -- Track consecutive wins per player

-- =====================
-- Data Persistence with Local Caching
-- =====================

local STATS_FILE = GetResourcePath(GetCurrentResourceName()) .. "/data/stats.json"
local STREAKS_FILE = GetResourcePath(GetCurrentResourceName()) .. "/data/streaks.json"

-- Cache state tracking
local CacheState = {
    statsDirty = false,      -- Track if stats need to be saved
    streaksDirty = false,    -- Track if streaks need to be saved
    lastSaveTime = 0,        -- Last time data was saved to disk
    saveInterval = 30000     -- Save interval in milliseconds (30 seconds)
}

local function LoadStats()
    local file = LoadResourceFile(GetCurrentResourceName(), "data/stats.json")
    if file then
        local data = json.decode(file)
        if data then
            EventStats = data
            -- Convert player IDs from strings to numbers if needed
            if EventStats.totalWins then
                local newWins = {}
                for k, v in pairs(EventStats.totalWins) do
                    newWins[tonumber(k) or k] = v
                end
                EventStats.totalWins = newWins
            end
            if EventStats.longestHolder then
                EventStats.longestHolder = tonumber(EventStats.longestHolder) or EventStats.longestHolder
            end
            if EventStats.mostWinsPlayer then
                EventStats.mostWinsPlayer = tonumber(EventStats.mostWinsPlayer) or EventStats.mostWinsPlayer
            end
        end
    end
    -- Reset dirty flag after loading
    CacheState.statsDirty = false
end

local function SaveStats(force)
    -- Mark as dirty (needs saving)
    CacheState.statsDirty = true
    
    -- If force is true, save immediately (for critical events)
    if force then
        local data = json.encode(EventStats)
        SaveResourceFile(GetCurrentResourceName(), "data/stats.json", data, -1)
        CacheState.statsDirty = false
        CacheState.lastSaveTime = GetGameTimer()
    end
end

local function LoadStreaks()
    local file = LoadResourceFile(GetCurrentResourceName(), "data/streaks.json")
    if file then
        local data = json.decode(file)
        if data then
            -- Convert player IDs from strings to numbers if needed
            local newStreaks = {}
            for k, v in pairs(data) do
                newStreaks[tonumber(k) or k] = v
            end
            PlayerStreaks = newStreaks
        end
    end
    -- Reset dirty flag after loading
    CacheState.streaksDirty = false
end

local function SaveStreaks(force)
    -- Mark as dirty (needs saving)
    CacheState.streaksDirty = true
    
    -- If force is true, save immediately (for critical events)
    if force then
        local data = json.encode(PlayerStreaks)
        SaveResourceFile(GetCurrentResourceName(), "data/streaks.json", data, -1)
        CacheState.streaksDirty = false
        CacheState.lastSaveTime = GetGameTimer()
    end
end

-- Periodic cache flush to disk
CreateThread(function()
    while true do
        Wait(CacheState.saveInterval) -- Wait for save interval
        
        local currentTime = GetGameTimer()
        local timeSinceLastSave = currentTime - CacheState.lastSaveTime
        local saved = false
        
        -- Save stats if dirty and enough time has passed
        if CacheState.statsDirty and timeSinceLastSave >= CacheState.saveInterval then
            local data = json.encode(EventStats)
            SaveResourceFile(GetCurrentResourceName(), "data/stats.json", data, -1)
            CacheState.statsDirty = false
            saved = true
        end
        
        -- Save streaks if dirty and enough time has passed
        if CacheState.streaksDirty and timeSinceLastSave >= CacheState.saveInterval then
            local data = json.encode(PlayerStreaks)
            SaveResourceFile(GetCurrentResourceName(), "data/streaks.json", data, -1)
            CacheState.streaksDirty = false
            saved = true
        end
        
        -- Update last save time if any save occurred
        if saved then
            CacheState.lastSaveTime = currentTime
        end
    end
end)

-- Save all cached data on resource stop
AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        -- Force save all dirty data before resource stops
        if CacheState.statsDirty then
            local data = json.encode(EventStats)
            SaveResourceFile(GetCurrentResourceName(), "data/stats.json", data, -1)
        end
        if CacheState.streaksDirty then
            local data = json.encode(PlayerStreaks)
            SaveResourceFile(GetCurrentResourceName(), "data/streaks.json", data, -1)
        end
    end
end)

-- Load data on server start
LoadStats()
LoadStreaks()

-- =====================
-- Event Start Function
-- =====================

local function StartVanEvent(adminSource)
    if EventActive then
        if adminSource then
            TriggerClientEvent('chat:addMessage', adminSource, {
                color = {255, 255, 0},
                args = {"System", "Van Hold event is already active!"}
            })
        end
        return false
    end

    EventActive = true
    VanHolder = nil
    HolderTeam = nil
    WinnerDeclared = false
    deadPlayers = {}
    EventStartTime = GetGameTimer()

    -- Select random location from Config.VAN_LOCATIONS
    local selectedLocation = nil
    if #Config.VAN_LOCATIONS > 0 then
        local randomIndex = math.random(1, #Config.VAN_LOCATIONS)
        selectedLocation = Config.VAN_LOCATIONS[randomIndex]
    else
        -- Fallback to admin's location if no locations defined
        if adminSource then
            local adminPed = GetPlayerPed(adminSource)
            selectedLocation = {
                name = "Admin Location",
                coords = GetEntityCoords(adminPed),
                heading = GetEntityHeading(adminPed),
                holdTime = Config.DEFAULT_HOLD_TIME or 40
            }
        else
            -- If no admin source and no locations, use default
            selectedLocation = {
                name = "Default Location",
                coords = vector3(0.0, 0.0, 0.0),
                heading = 0.0,
                holdTime = Config.DEFAULT_HOLD_TIME or 40
            }
        end
    end

    -- Set event duration (in minutes, convert to seconds)
    EventDuration = (Config.EVENT_DURATION or 15) * 60 -- Convert minutes to seconds
    EventStartTime = GetGameTimer()
    EventEndTime = EventStartTime + (EventDuration * 1000) -- Convert to milliseconds

    -- Update statistics
    EventStats.totalEvents = EventStats.totalEvents + 1
    SaveStats() -- Save after updating total events (cached, will save periodically)
    
    -- Get first player as spawner to prevent duplicates - only they create the van
    local players = GetPlayers()
    local spawnerId = tonumber(players[1]) or adminSource
    
    -- Store current event location for syncing to new players
    CurrentEventLocation = selectedLocation
    CurrentEventSpawnerId = spawnerId
    
    TriggerClientEvent('van:spawn', -1, selectedLocation.coords.x, selectedLocation.coords.y, selectedLocation.coords.z, selectedLocation.heading, selectedLocation.name, spawnerId)
    TriggerClientEvent('van:eventStarted', -1, EventDuration, selectedLocation.name, EventStats.totalEvents)
    
    if adminSource then
        -- Admin manually started the event
        TriggerClientEvent('chat:addMessage', adminSource, {
            color = {0, 255, 0},
            args = {"System", "Van Hold event started!"}
        })
    else
        -- Auto-spawned event
        TriggerClientEvent('chat:addMessage', -1, {
            color = {100, 150, 255},
            args = {"ASTRAL VAN HOLDS", "Van Hold event has started automatically!"}
        })
    end
    
    return true
end

-- =====================
-- Commands
-- =====================

RegisterCommand('startvan', function(source)
    -- Check if player has admin permissions
    if not IsPlayerAceAllowed(source, "command.startvan") then
        TriggerClientEvent('chat:addMessage', source, {
            color = {255, 0, 0},
            args = {"System", "You do not have permission to use this command."}
        })
        return
    end
    
    StartVanEvent(source)
end, true)

RegisterCommand('stopvan', function()
    EventActive = false
    VanHolder = nil
    HolderTeam = nil
    WinnerDeclared = false
    deadPlayers = {}
    EventStartTime = 0
    EventEndTime = 0
    EventDuration = 0
    CurrentEventLocation = nil
    CurrentEventSpawnerId = nil

    TriggerClientEvent('van:eventStopped', -1)
    TriggerClientEvent('van:cleanup', -1)
end, true)

RegisterCommand('vanstats', function(source)
    -- Build stats array from EventStats
    local statsArray = {}
    
    -- Add players from totalWins
    for playerId, wins in pairs(EventStats.totalWins) do
        local playerName = GetPlayerName(playerId) or "Unknown"
        if playerName ~= "Unknown" or wins > 0 then
            table.insert(statsArray, {
                name = playerName,
                kills = wins,  -- Using wins as "kills" for display
                deaths = 0,
                kd = wins > 0 and tostring(wins) or "0"
            })
        end
    end
    
    -- Sort by wins (kills) descending
    table.sort(statsArray, function(a, b)
        return a.kills > b.kills
    end)
    
    -- Limit to top 20
    local limitedStats = {}
    for i = 1, math.min(20, #statsArray) do
        table.insert(limitedStats, statsArray[i])
    end
    
    -- Send stats to client NUI
    TriggerClientEvent('van:showStats', source, limitedStats)
end, false)

-- =====================
-- Player Joining Handler
-- =====================

-- Function to sync event state to a player
local function SyncEventToPlayer(src)
    -- If event is active, sync the state to the player
    if EventActive and CurrentEventLocation then
        -- Wait a moment to ensure player is fully loaded
        Wait(1000)
        
        -- Send spawn event
        TriggerClientEvent('van:spawn', src, 
            CurrentEventLocation.coords.x, 
            CurrentEventLocation.coords.y, 
            CurrentEventLocation.coords.z, 
            CurrentEventLocation.heading, 
            CurrentEventLocation.name, 
            CurrentEventSpawnerId
        )
        
        -- Send event started event (with event duration)
        TriggerClientEvent('van:eventStarted', src, EventDuration, CurrentEventLocation.name, EventStats.totalEvents)
        
        -- Send current holder if there is one
        if VanHolder then
            local holderGang = nil
            if GetResourceState('qb-core') == 'started' then
                local QBCore = exports['qb-core']:GetCoreObject()
                local Player = QBCore.Functions.GetPlayer(VanHolder)
                if Player then
                    if Player.PlayerData.gang and Player.PlayerData.gang.name and Player.PlayerData.gang.name ~= "" then
                        holderGang = Player.PlayerData.gang.name
                    elseif Player.PlayerData.job and Player.PlayerData.job.name and Player.PlayerData.job.name ~= "" then
                        holderGang = TEAM_MAP[Player.PlayerData.job.name] or Player.PlayerData.job.name
                    end
                end
            end
            TriggerClientEvent('van:updateHolder', src, VanHolder, HolderTeam, holderGang)
        end
        
        -- Send current timer (remaining time)
        local remainingTime = math.max(0, (EventEndTime - GetGameTimer()) / 1000)
        TriggerClientEvent('van:updateTimer', src, math.floor(remainingTime))
    end
end

-- Sync event state to players who join mid-event (FiveM native event)
AddEventHandler('playerJoining', function()
    local src = source
    CreateThread(function()
        SyncEventToPlayer(src)
    end)
end)

-- Sync event state for QBCore players (if using QBCore)
if GetResourceState('qb-core') == 'started' then
    RegisterNetEvent('QBCore:Server:PlayerLoaded', function()
        local src = source
        CreateThread(function()
            SyncEventToPlayer(src)
        end)
    end)
end

-- Leaderboard command removed - stats are still tracked but no display command

-- =====================
-- Helper Functions
-- =====================

-- Check if player is in redzone 
local function IsPlayerInRedzone(src)
    if not EventActive or not CurrentEventLocation then return false end
    
    local playerPed = GetPlayerPed(src)
    if not playerPed or playerPed == 0 then return false end
    
    local playerCoords = GetEntityCoords(playerPed)
    local coords = CurrentEventLocation.coords
    local radius = Config.RedzoneBlip and Config.RedzoneBlip.radius or 250.0
    
    -- Use squared distance to avoid expensive square root
    local dx = playerCoords.x - coords.x
    local dy = playerCoords.y - coords.y
    local dz = playerCoords.z - coords.z
    local distanceSq = (dx * dx) + (dy * dy) + (dz * dz)
    local radiusSq = radius * radius
    
    return distanceSq <= radiusSq
end

-- =====================
-- Holder Management
-- =====================

RegisterNetEvent('van:setHolder', function(team, isAlive)
    local src = source
    
    DebugPrint("^3[VANHOLD SERVER] ========== CLAIM ATTEMPT ==========^7")
    DebugPrint("^3[VANHOLD SERVER] Player: " .. src .. " | Team: " .. tostring(team) .. " | IsAlive: " .. tostring(isAlive) .. "^7")
    DebugPrint("^3[VANHOLD SERVER] EventActive: " .. tostring(EventActive) .. " | WinnerDeclared: " .. tostring(WinnerDeclared) .. "^7")
    
    if not EventActive then
        DebugPrint("^1[VANHOLD SERVER] Event not active^7")
        -- Try both notification systems
        pcall(function()
            TriggerClientEvent('ox_lib:notify', src, {
                title = 'Error',
                description = 'No active event!',
                type = 'error',
                duration = 3000
            })
        end)
        TriggerClientEvent('chat:addMessage', src, {
            color = {255, 0, 0},
            args = {"[VANHOLD]", "No active event!"}
        })
        return
    end
    
    if WinnerDeclared then
        DebugPrint("^1[VANHOLD SERVER] Winner already declared^7")
        return
    end
    
    if not isAlive then
        DebugPrint("^1[VANHOLD SERVER] Player not alive^7")
        return
    end
    
    if deadPlayers[src] then
        DebugPrint("^1[VANHOLD SERVER] Player is dead^7")
        return
    end
    
    -- Validate player is near van location (within 2m) and in redzone
    if not CurrentEventLocation then
        DebugPrint("^1[VANHOLD SERVER] No event location set^7")
        return
    end
    
    local playerPed = GetPlayerPed(src)
    if not playerPed or playerPed == 0 then return end
    
    local playerCoords = GetEntityCoords(playerPed)
    local vanCoords = CurrentEventLocation.coords
    
    -- Check distance to van (must be within 2.5m to claim - slightly more lenient for server validation)
    local dx = playerCoords.x - vanCoords.x
    local dy = playerCoords.y - vanCoords.y
    local dz = playerCoords.z - vanCoords.z
    local distanceSq = (dx * dx) + (dy * dy) + (dz * dz)
    local claimDistSq = 2.5 * 2.5 -- 2.5 meters squared (slightly more lenient for server)
    local actualDist = math.sqrt(distanceSq)
    
    DebugPrint("^3[VANHOLD SERVER] Distance check - Player distance from van: " .. string.format("%.2f", actualDist) .. "m^7")
    
    if distanceSq > claimDistSq then
        DebugPrint("^1[VANHOLD SERVER] Player too far from van: " .. string.format("%.2f", actualDist) .. "m (max: 2.5m)^7")
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Error',
            description = 'You must be within 2 meters of the van to claim it!',
            type = 'error',
            duration = 3000
        })
        return
    end
    
    DebugPrint("^2[VANHOLD SERVER] Distance check passed: " .. string.format("%.2f", actualDist) .. "m^7")
    
    -- Also check if in redzone (must be in redzone to maintain claim)
    if not IsPlayerInRedzone(src) then
        DebugPrint("^1[VANHOLD SERVER] Player not in redzone^7")
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Error',
            description = 'You must be in the redzone to claim the van!',
            type = 'error',
            duration = 3000
        })
        return
    end
    
    DebugPrint("^2[VANHOLD SERVER] ========== ALL CHECKS PASSED ==========^7")
    DebugPrint("^2[VANHOLD SERVER] Setting holder - Player: " .. src .. " | Team: " .. tostring(team) .. "^7")
    
    -- Allow players to take over the van from current holder
    local previousHolder = VanHolder
    local previousHolderName = previousHolder and GetPlayerName(previousHolder) or nil
    
    VanHolder = src
    HolderTeam = team
    
    DebugPrint("^2[VANHOLD SERVER] Holder set successfully! Previous: " .. tostring(previousHolder) .. " | New: " .. tostring(VanHolder) .. "^7")
    
    -- Notify if someone took over from another player
    if previousHolder and previousHolder ~= src then
        local newHolderName = GetPlayerName(src) or "Unknown"
        DebugPrint("^3[VANHOLD SERVER] " .. newHolderName .. " took over the van from " .. (previousHolderName or "Unknown") .. "^7")
        
        -- Notify the previous holder they lost it
        if previousHolder then
            TriggerClientEvent('ox_lib:notify', previousHolder, {
                title = 'Claim Lost',
                description = newHolderName .. ' has taken over the van!',
                type = 'warning',
                duration = 5000
            })
        end
        
        -- Notify all players about the takeover
        TriggerClientEvent('chat:addMessage', -1, {
            color = {255, 165, 0},
            args = {"ASTRAL VAN HOLDS", newHolderName .. " has taken over the van from " .. (previousHolderName or "Unknown") .. "!"}
        })
    end
    
    -- Get gang/job info for holder - check gang first, then job
    local holderGang = nil
    if GetResourceState('qb-core') == 'started' then
        local QBCore = exports['qb-core']:GetCoreObject()
        local Player = QBCore.Functions.GetPlayer(src)
        if Player then
            -- Check for gang first
            if Player.PlayerData.gang and Player.PlayerData.gang.name and Player.PlayerData.gang.name ~= "" then
                holderGang = Player.PlayerData.gang.name
            -- If no gang, check for job via QBCore
            elseif Player.PlayerData.job and Player.PlayerData.job.name and Player.PlayerData.job.name ~= "" then
                -- Use TEAM_MAP if available, otherwise use the job name directly
                holderGang = TEAM_MAP[Player.PlayerData.job.name] or Player.PlayerData.job.name
            end
        end
    end
    
    DebugPrint("^2[VANHOLD SERVER] Holder set: " .. tostring(VanHolder) .. " | Team: " .. tostring(HolderTeam) .. " | Gang: " .. tostring(holderGang) .. "^7")
    
    TriggerClientEvent('van:updateHolder', -1, VanHolder, HolderTeam, holderGang)
    
    -- Notify the claimer
    TriggerClientEvent('ox_lib:notify', src, {
        title = 'Claim Secured',
        description = 'You are now holding the van! Defend it until the event ends!',
        type = 'success',
        duration = 6000
    })
end)

RegisterNetEvent('van:clearHolder', function()
    local src = source
    
    if not EventActive then return end
    if VanHolder ~= src then return end

    VanHolder = nil
    HolderTeam = nil
    TriggerClientEvent('van:updateHolder', -1, nil, nil, nil)
end)

-- =====================
-- Death Management
-- =====================

RegisterNetEvent('playerDied', function()
    local src = source
    deadPlayers[src] = true

    if VanHolder == src then
        VanHolder = nil
        HolderTeam = nil
        -- Claim lost on death
        TriggerClientEvent('van:updateHolder', -1, nil, nil, nil)
        TriggerClientEvent('van:updateTimer', -1, HoldTime)
    end
end)

RegisterNetEvent('playerRespawned', function()
    local src = source
    deadPlayers[src] = nil
end)

-- =====================
-- Timer & Win Condition
-- =====================

CreateThread(function()
    while true do
        Wait(1000)
        
        if EventActive and not WinnerDeclared then
            local currentTime = GetGameTimer()
            
            -- Check if event duration has elapsed
            if currentTime >= EventEndTime then
                -- Event ended - whoever is holding wins
                EventActive = false
                WinnerDeclared = true
                
                if VanHolder then
                    -- There's a winner 
                    local winnerName = GetPlayerName(VanHolder) or "Unknown"
                    local winnerTeam = HolderTeam or "Unknown"
                    
                    -- Get gang/job info if available (QBCore) - check gang first, then job
                    local winnerRole = nil
                    if GetResourceState('qb-core') == 'started' then
                        local QBCore = exports['qb-core']:GetCoreObject()
                        local Player = QBCore.Functions.GetPlayer(VanHolder)
                        if Player then
                            -- Check for gang first
                            if Player.PlayerData.gang and Player.PlayerData.gang.name then
                                winnerRole = Player.PlayerData.gang.name
                            -- If no gang, check for job
                            elseif Player.PlayerData.job and Player.PlayerData.job.name then
                                winnerRole = TEAM_MAP[Player.PlayerData.job.name] or Player.PlayerData.job.name
                            end
                        end
                    end
                    
                    -- Update statistics
                    if not EventStats.totalWins[VanHolder] then
                        EventStats.totalWins[VanHolder] = 0
                    end
                    EventStats.totalWins[VanHolder] = EventStats.totalWins[VanHolder] + 1
                    
                    -- Track most wins
                    if EventStats.totalWins[VanHolder] > EventStats.mostWins then
                        EventStats.mostWins = EventStats.totalWins[VanHolder]
                        EventStats.mostWinsPlayer = VanHolder
                    end
                    
                    -- Save stats after update (force save on win - critical event)
                    SaveStats(true)
                    
                    -- Streak System: Track consecutive wins
                    local currentStreak = 1
                    if Config.STREAK_ENABLED then
                        if not PlayerStreaks[VanHolder] then
                            PlayerStreaks[VanHolder] = 0
                        end
                        -- Increment streak (consecutive win)
                        PlayerStreaks[VanHolder] = PlayerStreaks[VanHolder] + 1
                        currentStreak = PlayerStreaks[VanHolder]
                        
                        -- Reset streaks for all other players (they didn't win)
                        for playerId, _ in pairs(PlayerStreaks) do
                            if playerId ~= VanHolder then
                                PlayerStreaks[playerId] = 0
                            end
                        end
                        
                        -- Save streaks after update (force save on win - critical event)
                        SaveStreaks(true)
                    end
                    
                    -- Format winner text with gang/job if available
                    local winnerText = winnerName
                    if winnerRole then
                        winnerText = string.format("%s %s", winnerName, winnerRole)
                    end
                    
                    -- Give random loot to winner using ox_inventory
                    if GetResourceState('ox_inventory') == 'started' and #Config.LOOT_POOL > 0 then
                        -- Process each item in the loot pool
                        for _, loot in ipairs(Config.LOOT_POOL) do
                            if loot.item and loot.minCount and loot.maxCount then
                                -- Validate counts
                                local minCount = math.max(1, loot.minCount or 1)
                                local maxCount = math.max(minCount, loot.maxCount or minCount)
                                -- Validate chance (default to 100 if not specified)
                                local chance = math.max(0, math.min(100, loot.chance or 100))
                                -- Validate minItems/maxItems (default to 1 if not specified)
                                local minItems = math.max(0, loot.minItems or 1)
                                local maxItems = math.max(minItems, loot.maxItems or minItems)
                                
                                -- Determine how many times to try giving this item
                                local itemsToGive = math.random(minItems, maxItems)
                                
                                -- Try to give the item the specified number of times
                                for i = 1, itemsToGive do
                                    -- Roll for chance (0-100)
                                    local roll = math.random(1, 100)
                                    
                                    -- Only give item if chance roll passes
                                    if roll <= chance then
                                        -- Randomize the count for this item based on its min/max
                                        local randomCount = math.random(minCount, maxCount)
                                        
                                        -- Give the item to the winner with random count
                                        exports.ox_inventory:AddItem(VanHolder, loot.item, randomCount)
                                    end
                                end
                            end
                        end
                    end
                    
                    -- Streak System: Give bonus rewards for consecutive wins
                    if Config.STREAK_ENABLED and currentStreak > 1 and Config.STREAK_BONUS_LOOT and #Config.STREAK_BONUS_LOOT > 0 then
                        local streakRewardGiven = false
                        for _, streakReward in ipairs(Config.STREAK_BONUS_LOOT) do
                            if currentStreak >= streakReward.streak then
                                -- Give bonus items for this streak level
                                if streakReward.items and #streakReward.items > 0 then
                                    for _, bonusItem in ipairs(streakReward.items) do
                                        if bonusItem.item and bonusItem.minCount and bonusItem.maxCount then
                                            local minCount = math.max(1, bonusItem.minCount or 1)
                                            local maxCount = math.max(minCount, bonusItem.maxCount or minCount)
                                            local chance = math.max(0, math.min(100, bonusItem.chance or 100))
                                            
                                            local roll = math.random(1, 100)
                                            if roll <= chance then
                                                local randomCount = math.random(minCount, maxCount)
                                                exports.ox_inventory:AddItem(VanHolder, bonusItem.item, randomCount)
                                                streakRewardGiven = true
                                            end
                                        end
                                    end
                                end
                            end
                        end
                        
                        if streakRewardGiven then
                            TriggerClientEvent('chat:addMessage', VanHolder, {
                                color = {255, 215, 0},
                                args = {"ASTRAL VAN HOLDS", string.format("🔥 STREAK BONUS! %d consecutive wins! Bonus rewards added! 🔥", currentStreak)}
                            })
                        end
                    end
                    
                    -- Announce winner to all players
                    local chatMessage = string.format("^2%s^7 has won the Van Hold event!", winnerText)
                    if winnerTeam and winnerTeam ~= "Unknown" then
                        chatMessage = string.format("^2%s^7 (%s) has won the Van Hold event!", winnerText, winnerTeam)
                    end
                    
                    -- Add streak info to announcement if streak is active
                    if Config.STREAK_ENABLED and currentStreak > 1 then
                        chatMessage = chatMessage .. string.format(" 🔥 %d WIN STREAK! 🔥", currentStreak)
                    end
                    
                    TriggerClientEvent('chat:addMessage', -1, {
                        color = {100, 150, 255},
                        multiline = true,
                        args = {"ASTRAL VAN HOLDS", chatMessage}
                    })
                    
                    TriggerClientEvent('van:declareWinner', -1, VanHolder, HolderTeam, winnerRole)
                    TriggerClientEvent('van:cleanup', -1)
                    
                    -- Clear current event location
                    CurrentEventLocation = nil
                    CurrentEventSpawnerId = nil
                else
                    -- No winner - event ended with no holder
                    TriggerClientEvent('chat:addMessage', -1, {
                        color = {255, 165, 0},
                        args = {"ASTRAL VAN HOLDS", "Van Hold event ended - No one claimed the van!"}
                    })
                    
                    TriggerClientEvent('van:eventStopped', -1)
                    TriggerClientEvent('van:cleanup', -1)
                    
                    -- Reset all streaks when event times out (no winner)
                    if Config.STREAK_ENABLED then
                        for playerId, _ in pairs(PlayerStreaks) do
                            PlayerStreaks[playerId] = 0
                        end
                        SaveStreaks(true) -- Force save on timeout (important state change)
                    end
                    
                    -- Clear current event location
                    CurrentEventLocation = nil
                    CurrentEventSpawnerId = nil
                end
            else
                -- Event still active - check holder status and send timer updates
                -- Check if holder is still within hold radius of van
                if VanHolder then
                    if deadPlayers[VanHolder] then
                        -- Holder died - lose claim
                        VanHolder = nil
                        HolderTeam = nil
                        TriggerClientEvent('van:updateHolder', -1, nil, nil, nil)
                    else
                        -- Check if holder is within 50m of van location
                        local holderPed = GetPlayerPed(VanHolder)
                        if holderPed and holderPed ~= 0 then
                            local holderCoords = GetEntityCoords(holderPed)
                            local vanCoords = CurrentEventLocation.coords
                            
                            local dx = holderCoords.x - vanCoords.x
                            local dy = holderCoords.y - vanCoords.y
                            local dz = holderCoords.z - vanCoords.z
                            local distanceSq = (dx * dx) + (dy * dy) + (dz * dz)
                            local holdRadiusSq = 50.0 * 50.0 -- 50 meters squared
                            
                            if distanceSq > holdRadiusSq then
                                -- Holder left van radius - lose claim
                                local holderId = VanHolder -- Store before clearing
                                local holderName = GetPlayerName(holderId) or "Unknown"
                                DebugPrint("^1[VANHOLD SERVER] " .. holderName .. " left van radius, losing claim^7")
                                
                                VanHolder = nil
                                HolderTeam = nil
                                TriggerClientEvent('van:updateHolder', -1, nil, nil, nil)
                                
                                -- Notify the player
                                TriggerClientEvent('ox_lib:notify', holderId, {
                                    title = 'Claim Lost',
                                    description = 'You left the van radius and lost the claim!',
                                    type = 'error',
                                    duration = 3000
                                })
                            end
                        end
                    end
                end
                
                -- Calculate and send remaining time (countdown timer)
                local remainingTime = math.max(0, (EventEndTime - currentTime) / 1000) -- Convert to seconds
                TriggerClientEvent('van:updateTimer', -1, math.floor(remainingTime))
            end
        end
    end
end)

-- =====================
-- Auto-Spawn Timer
-- =====================

CreateThread(function()
    -- Wait a moment for config to load
    Wait(5000)
    
    if not Config or not Config.AUTO_SPAWN_ENABLED then
        return -- Exit if auto-spawn is disabled or config not loaded
    end
    
    -- Convert minutes to milliseconds (1 minute = 60000 ms)
    local intervalMs = (Config.AUTO_SPAWN_INTERVAL or 60) * 60000
    
    -- Wait a short time on server start before first spawn (30 seconds)
    Wait(30000)
    
    while true do
        -- Only start if no event is active
        if not EventActive then
            -- Pre-event announcements
            if Config.PRE_EVENT_ANNOUNCEMENT and Config.ANNOUNCEMENT_TIME and Config.ANNOUNCEMENT_TIME > 0 then
                local announcementStart = GetGameTimer()
                local announcementTimeMs = (Config.ANNOUNCEMENT_TIME or 5) * 60000
                local timeUntilEvent = intervalMs
                
                -- Announce at different intervals
                while GetGameTimer() - announcementStart < intervalMs and not EventActive do
                    local timeRemaining = intervalMs - (GetGameTimer() - announcementStart)
                    local minutesRemaining = math.floor(timeRemaining / 60000)
                    local secondsRemaining = math.floor((timeRemaining % 60000) / 1000)
                    
                    -- Announce at 5 min, 3 min, 1 min, 30 sec, 10 sec
                    if timeRemaining <= 300000 and timeRemaining > 299000 then -- 5 minutes
                        TriggerClientEvent('chat:addMessage', -1, {
                            color = {100, 150, 255},
                            args = {"ASTRAL VAN HOLDS", "Van Hold event starting in 5 minutes!"}
                        })
                        TriggerClientEvent('van:preEventAnnouncement', -1, 5, "minutes")
                    elseif timeRemaining <= 180000 and timeRemaining > 179000 then -- 3 minutes
                        TriggerClientEvent('chat:addMessage', -1, {
                            color = {100, 150, 255},
                            args = {"ASTRAL VAN HOLDS", "Van Hold event starting in 3 minutes!"}
                        })
                        TriggerClientEvent('van:preEventAnnouncement', -1, 3, "minutes")
                    elseif timeRemaining <= 60000 and timeRemaining > 59000 then -- 1 minute
                        TriggerClientEvent('chat:addMessage', -1, {
                            color = {255, 165, 0},
                            args = {"ASTRAL VAN HOLDS", "Van Hold event starting in 1 minute!"}
                        })
                        TriggerClientEvent('van:preEventAnnouncement', -1, 1, "minute")
                    elseif timeRemaining <= 30000 and timeRemaining > 29000 then -- 30 seconds
                        TriggerClientEvent('chat:addMessage', -1, {
                            color = {255, 165, 0},
                            args = {"ASTRAL VAN HOLDS", "Van Hold event starting in 30 seconds!"}
                        })
                        TriggerClientEvent('van:preEventAnnouncement', -1, 30, "seconds")
                    elseif timeRemaining <= 10000 and timeRemaining > 9000 then -- 10 seconds
                        TriggerClientEvent('chat:addMessage', -1, {
                            color = {255, 0, 0},
                            args = {"ASTRAL VAN HOLDS", "Van Hold event starting in 10 seconds!"}
                        })
                        TriggerClientEvent('van:preEventAnnouncement', -1, 10, "seconds")
                    end
                    
                    Wait(1000) -- Check every second
                end
            end
            
            StartVanEvent(nil) -- nil = automatic spawn (no admin source)
        end
        
        -- Wait for the interval before next check
        Wait(intervalMs)
    end
end)
