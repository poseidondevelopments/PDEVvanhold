-- =====================
-- Van Hold Event - Client
-- =====================

local van, vanBlip, zoneBlip = nil, nil, nil
local eventActive = false
local holding = false
local holder = nil
local holderTeam = nil
local holderGang = nil
local holdTime = 0
local maxTime = 0
local wasDead = false
local notificationEndTime = 0
local winnerNotificationEndTime = 0
local winnerName = nil
local winnerTeam = nil
local countdownEndTime = 0
local canClaim = false
local vanLocationName = nil
local showLeaderboard = false
local leaderboardData = {}
local killFeedText = nil
local killFeedEndTime = 0

-- Config
local HOLD_RADIUS = 50.0
local CLAIM_DISTANCE = 2.0 -- Distance to press E to claim the van
local vanModel = `speedo`
local NOTIFICATION_DURATION = 5000 -- 5 seconds
local WINNER_NOTIFICATION_DURATION = 20000 -- 20 seconds
local TELEPORT_DISTANCE = 100.0 -- Distance to teleport away from van
local COUNTDOWN_DURATION = 20000 -- 5 seconds
local COUNTDOWN_DELAY = 5000 -- 5 seconds delay before countdown starts

local TEAM_MAP = {
    police = 'Police',
    sheriff = 'Sheriff',
    ambulance = 'EMS'
}

-- =====================
-- Event Handlers
-- =====================

RegisterNetEvent('van:eventStarted', function(max, locationName, totalEvents)
    eventActive = true
    maxTime = max
    holdTime = 0
    holder = nil
    holderTeam = nil
    holderGang = nil
    canClaim = false
    vanLocationName = locationName
    
    -- Start countdown after delay (5 seconds after event start, then 5 second countdown)
    countdownEndTime = GetGameTimer() + COUNTDOWN_DELAY + COUNTDOWN_DURATION
    
    -- Show improved notification with more details
    local notificationText = string.format('HOLD THE VAN EVENT STARTED\nLocation: %s\nHold Time Required: %d seconds\nEvent #%d', 
        locationName or "Unknown", 
        maxTime,
        totalEvents or 0
    )
    lib.notify({
        title = 'ASTRAL VAN HOLDS',
        description = notificationText,
        type = 'inform',
        duration = NOTIFICATION_DURATION
    })
    
    -- Play sound effect
    PlaySoundFrontend(-1, "Mission_Pass_Notify", "DLC_HEISTS_GENERAL_FRONTEND_SOUNDS", true)
end)

RegisterNetEvent('van:eventStopped', function()
    eventActive = false
    holder = nil
    holderTeam = nil
    holderGang = nil
    winnerName = nil
    winnerTeam = nil
    if holding then
        holding = false
        TriggerServerEvent('van:clearHolder')
    end
end)

RegisterNetEvent('van:spawn', function(x, y, z, heading, locationName)
    vanLocationName = locationName
    -- Delete existing van if it exists
    if van and DoesEntityExist(van) then
        DeleteEntity(van)
        van = nil
    end
    
    -- Clean up any existing blips
    if vanBlip and DoesBlipExist(vanBlip) then
        RemoveBlip(vanBlip)
        vanBlip = nil
    end
    if zoneBlip and DoesBlipExist(zoneBlip) then
        RemoveBlip(zoneBlip)
        zoneBlip = nil
    end
    
    local coords = vector3(x, y, z)
    heading = heading or 0.0

    RequestModel(vanModel)
    while not HasModelLoaded(vanModel) do Wait(0) end

    -- Check if a van already exists at this location (within 10m) to avoid duplicates
    local nearbyVan = GetClosestVehicle(coords.x, coords.y, coords.z, 10.0, 0, 71)
    if nearbyVan and nearbyVan ~= 0 and DoesEntityExist(nearbyVan) then
        local model = GetEntityModel(nearbyVan)
        if model == vanModel then
            -- Use existing van instead of creating new one
            van = nearbyVan
        else
            van = CreateVehicle(vanModel, coords.x, coords.y, coords.z, heading, true, true)
        end
    else
        van = CreateVehicle(vanModel, coords.x, coords.y, coords.z, heading, true, true)
    end
    
    -- Set van properties
    SetEntityInvincible(van, true)
    SetVehicleTowable(van, false)
    SetVehicleCanBeVisiblyDamaged(van, false)
    SetEntityAsMissionEntity(van, true, true)
    
    -- Network the vehicle properly
    local netId = NetworkGetNetworkIdFromEntity(van)
    SetNetworkIdCanMigrate(netId, false)
    NetworkRegisterEntityAsNetworked(van)

    -- Wait a frame to ensure vehicle is fully created
    Wait(200)
    
    -- Create van blip with enhanced styling
    if vanBlip and DoesBlipExist(vanBlip) then 
        RemoveBlip(vanBlip) 
    end
    vanBlip = AddBlipForEntity(van)
    SetBlipSprite(vanBlip, Config.BLIP_SETTINGS.vanSprite or 67)
    SetBlipColour(vanBlip, Config.BLIP_SETTINGS.vanColor or 5)
    SetBlipScale(vanBlip, Config.BLIP_SETTINGS.vanScale or 1.2)
    SetBlipAsShortRange(vanBlip, false)
    SetBlipDisplay(vanBlip, 4)
    SetBlipCategory(vanBlip, 2)
    SetBlipFlashes(vanBlip, true)  -- Make it flash to draw attention
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentSubstringPlayerName("Hold The Van")
    EndTextCommandSetBlipName(vanBlip)

    -- Create zone radius blip with enhanced styling
    if zoneBlip and DoesBlipExist(zoneBlip) then 
        RemoveBlip(zoneBlip) 
    end
    zoneBlip = AddBlipForRadius(coords.x, coords.y, coords.z, HOLD_RADIUS)
    SetBlipColour(zoneBlip, Config.BLIP_SETTINGS.zoneColor or 1)
    SetBlipAlpha(zoneBlip, Config.BLIP_SETTINGS.zoneAlpha or 120)
    SetBlipScale(zoneBlip, Config.BLIP_SETTINGS.zoneScale or 1.0)
    SetBlipAsShortRange(zoneBlip, true)
    SetBlipDisplay(zoneBlip, 4)
    
end)

RegisterNetEvent('van:updateHolder', function(id, team, gang)
    local previousHolder = holder
    holder = id
    holderTeam = team
    holderGang = gang
    
    -- Play sound when someone takes the van
    if id and id ~= previousHolder then
        PlaySoundFrontend(-1, "CHECKPOINT_PERFECT", "HUD_MINI_GAME_SOUNDSET", true)
        
        -- Show notification if you're not the holder
        if id ~= GetPlayerServerId(PlayerId()) then
            local holderName = GetPlayerName(GetPlayerFromServerId(id)) or "Unknown"
            lib.notify({
                title = 'ASTRAL VAN HOLDS',
                description = string.format('%s has claimed the van!', holderName),
                type = 'inform',
                duration = 3000
            })
        end
    end
end)

local lastLowTimeWarning = 0
RegisterNetEvent('van:updateTimer', function(time)
    local previousTime = holdTime
    holdTime = time
    
    -- Play warning sound when timer is running low (last 10 seconds)
    if eventActive and holder == GetPlayerServerId(PlayerId()) and maxTime > 0 then
        local timeRemaining = maxTime - time
        if timeRemaining <= 10 and timeRemaining > 0 and previousTime ~= time then
            local currentTime = GetGameTimer()
            -- Only play sound once per second to avoid spam
            if currentTime - lastLowTimeWarning > 1000 then
                PlaySoundFrontend(-1, "TIMER_STOP", "HUD_MINI_GAME_SOUNDSET", true)
                lastLowTimeWarning = currentTime
                
                -- Show warning notification at 10, 5, and 1 second
                if timeRemaining == 10 or timeRemaining == 5 or timeRemaining == 1 then
                    lib.notify({
                        title = 'ASTRAL VAN HOLDS',
                        description = string.format('WARNING: %d seconds remaining!', timeRemaining),
                        type = 'error',
                        duration = 2000
                    })
                end
            end
        end
    end
end)

RegisterNetEvent('van:declareWinner', function(id, team, gang)
    eventActive = false
    if holding then
        holding = false
        TriggerServerEvent('van:clearHolder')
    end
    
    PlaySoundFrontend(-1, "MP_WAVE_COMPLETE", "HUD_FRONTEND_DEFAULT_SOUNDSET", true)
    
    -- Spawn confetti at van location
    if DoesEntityExist(van) then
        CreateConfetti(van)
    end
    
    local name = GetPlayerName(GetPlayerFromServerId(id)) or "Unknown"
    winnerTeam = team
    
    -- Format winner name with gang/job if available
    if gang then
        winnerName = string.format("%s %s", name, gang)
    else
        winnerName = name
    end
    
    -- Show improved winner notification with more details
    local isWinner = (id == GetPlayerServerId(PlayerId()))
    local winnerDescription = string.format('WINNER: %s', winnerName)
    if winnerTeam and winnerTeam ~= "Unknown" then
        winnerDescription = string.format('WINNER: %s (%s)', winnerName, winnerTeam)
    end
    
    if isWinner then
        winnerDescription = winnerDescription .. '\n🎉 CONGRATULATIONS! You won! 🎉'
    end
    
    lib.notify({
        title = 'ASTRAL VAN HOLDS',
        description = winnerDescription,
        type = 'success',
        duration = WINNER_NOTIFICATION_DURATION
    })
    
    holder = nil
    holderTeam = nil
    holderGang = nil
end)

RegisterNetEvent('van:cleanup', function()
    eventActive = false
    if holding then
        holding = false
        TriggerServerEvent('van:clearHolder')
    end
    
    
    if DoesEntityExist(van) then DeleteEntity(van) end
    if vanBlip and DoesBlipExist(vanBlip) then RemoveBlip(vanBlip) end
    if zoneBlip and DoesBlipExist(zoneBlip) then RemoveBlip(zoneBlip) end
    van, vanBlip, zoneBlip = nil, nil, nil
    holder = nil
    holderTeam = nil
    holderGang = nil
    vanLocationName = nil
end)

RegisterNetEvent('van:showLeaderboard', function(data)
    leaderboardData = data or {}
    showLeaderboard = true
    
    -- Auto-hide after 15 seconds
    CreateThread(function()
        Wait(15000)
        showLeaderboard = false
        leaderboardData = {}
    end)
end)

RegisterNetEvent('van:killFeed', function(killerName, victimName)
    if killerName and victimName then
        killFeedText = string.format("%s killed %s (Van Holder)", killerName, victimName)
    elseif victimName then
        killFeedText = string.format("%s died (Van Holder)", victimName)
    end
    
    killFeedEndTime = GetGameTimer() + 5000 -- Show for 5 seconds
    
    -- Auto-hide kill feed
    CreateThread(function()
        Wait(5000)
        killFeedText = nil
    end)
end)

RegisterNetEvent('van:preEventAnnouncement', function(time, unit)
    local announcementText = string.format("Van Hold starting in %d %s!", time, unit)
    lib.notify({
        title = 'ASTRAL VAN HOLDS',
        description = announcementText,
        type = 'inform',
        duration = 5000
    })
end)

-- =====================
-- Death Detection
-- =====================

CreateThread(function()
    while true do
        Wait(0)
        local ped = PlayerPedId()
        local isDead = IsEntityDead(ped) or IsPedDeadOrDying(ped, true) or GetEntityHealth(ped) <= 0
        
        if isDead and not wasDead then
            wasDead = true
            if holding then
                holding = false
                TriggerServerEvent('van:clearHolder')
            end
            -- Teleport away from van if it exists and event is active
            if eventActive and van and DoesEntityExist(van) then
                CreateThread(function()
                    Wait(500) -- Wait a bit for death to fully register
                    if DoesEntityExist(van) then
                        TeleportAwayFromVan()
                    end
                end)
            end
            -- Try to get killer information
            local killerPed = GetPedSourceOfDeath(ped)
            local killerId = nil
            
            if killerPed and killerPed ~= 0 then
                -- Try to find the player who owns this ped
                for _, playerId in ipairs(GetActivePlayers()) do
                    if GetPlayerPed(playerId) == killerPed then
                        killerId = GetPlayerServerId(playerId)
                        break
                    end
                end
            end
            
            TriggerServerEvent('playerDied', killerId)
        elseif not isDead and wasDead then
            wasDead = false
            TriggerServerEvent('playerRespawned')
        end
    end
end)

-- =====================
-- Hold Logic
-- =====================

function ClaimVan()
    if not eventActive or not DoesEntityExist(van) then return end
    
    local ped = PlayerPedId()
    local isDead = IsEntityDead(ped) or IsPedDeadOrDying(ped, true) or GetEntityHealth(ped) <= 0
    
    if isDead or wasDead then return end
    
    local pedCoords = GetEntityCoords(ped)
    local vanCoords = GetEntityCoords(van)
    local dist = #(pedCoords - vanCoords)
    
    if dist <= HOLD_RADIUS and canClaim then
        if not holding then
            holding = true
            TriggerServerEvent('van:setHolder', GetPlayerTeam(), true)
        end
    end
end

-- E Key Detection and UI
CreateThread(function()
    while true do
        Wait(0)
        
        if eventActive and DoesEntityExist(van) and canClaim then
            local ped = PlayerPedId()
            local isDead = IsEntityDead(ped) or IsPedDeadOrDying(ped, true) or GetEntityHealth(ped) <= 0
            
            if not isDead and not wasDead and not holding then
                local pedCoords = GetEntityCoords(ped)
                local vanCoords = GetEntityCoords(van)
                local dist = #(pedCoords - vanCoords)
                
                if dist <= CLAIM_DISTANCE then
                    -- Show UI prompt
                    DrawText2D(0.5, 0.85, "Press [E] to Claim The Van", true, 0.5)
                    
                    -- Check for E key press
                    if IsControlJustPressed(0, 38) then -- E key
                        ClaimVan()
                    end
                end
            end
        end
    end
end)

CreateThread(function()
    while true do
        Wait(1000)
        
        if not eventActive or not DoesEntityExist(van) then
            if holding then
                holding = false
                TriggerServerEvent('van:clearHolder')
            end
            goto continue
        end

        local ped = PlayerPedId()
        local isDead = IsEntityDead(ped) or IsPedDeadOrDying(ped, true) or GetEntityHealth(ped) <= 0
        
        if isDead or wasDead then
            if holding then
                holding = false
                TriggerServerEvent('van:clearHolder')
            end
            goto continue
        end

        -- Check if countdown is finished
        if GetGameTimer() >= countdownEndTime then
            canClaim = true
        end
        
        -- Check if player is still in radius (if holding, clear if too far)
        if holding then
            local pedCoords = GetEntityCoords(ped)
            local vanCoords = GetEntityCoords(van)
            local dist = #(pedCoords - vanCoords)
            
            if dist > HOLD_RADIUS then
                holding = false
                TriggerServerEvent('van:clearHolder')
            end
        end

        ::continue::
    end
end)

-- =====================
-- Leaderboard Toggle
-- =====================

CreateThread(function()
    while true do
        Wait(0)
        if showLeaderboard then
            -- Check for ESC key to close leaderboard
            if IsControlJustPressed(0, 322) then -- ESC key
                showLeaderboard = false
                leaderboardData = {}
            end
        end
    end
end)

-- =====================
-- UI Rendering (ox_lib Style)
-- =====================

CreateThread(function()
    while true do
        Wait(0)
        
        if eventActive then
            -- Top-left: Holder info using ox_lib text UI style
            local hudX, hudY = 0.015, 0.02
            local hudText = ""
            
            if holder then
                local name = GetPlayerName(GetPlayerFromServerId(holder)) or "Unknown"
                local timeText = string.format("%d / %d", holdTime, maxTime)
                local displayName = name
                if holderGang then
                    displayName = string.format("%s %s", name, holderGang)
                end
                if holderTeam and holderTeam ~= "Unknown" then
                    hudText = string.format("VAN HOLD\nHolder: %s (%s)\nTime: %s", displayName, holderTeam, timeText)
                else
                    hudText = string.format("VAN HOLD\nHolder: %s\nTime: %s", displayName, timeText)
                end
            else
                hudText = "VAN HOLD\nUnoccupied"
            end
            
            -- Draw text in ox_lib style (clean, no background)
            DrawText2D(hudX, hudY, hudText, false, 0.42)
            
            -- Show countdown using ox_lib notification style
            if GetGameTimer() < countdownEndTime and GetGameTimer() >= (countdownEndTime - COUNTDOWN_DURATION) then
                local countdown = math.ceil((countdownEndTime - GetGameTimer()) / 1000)
                local countdownText = string.format("STARTING IN: %d", countdown)
                DrawText2D(0.5, 0.5, countdownText, true, 0.6)
            end
            
            -- Holding indicator using ox_lib style
            if holder == GetPlayerServerId(PlayerId()) then
                local indicatorY = 0.08
                local indicatorText = "YOU ARE HOLDING THE VAN"
                local ASTRALText = "ASTRAL VAN HOLDS"
                DrawText2D(0.5, indicatorY - 0.025, ASTRALText, true, 0.38)
                DrawText2D(0.5, indicatorY, indicatorText, true, 0.5)
            end
            
            -- Bottom center: Location display
            if vanLocationName then
                local locationText = string.format("Van Location: %s", vanLocationName)
                DrawText2D(0.5, 0.89, locationText, true, 0.45)
            end
        end
        
        -- Draw leaderboard UI (always check, even when event is not active)
        if showLeaderboard then
            DrawLeaderboard()
        end
    end
end)

-- =====================
-- Utility Functions
-- =====================

function GetPlayerTeam()
    -- Check for QBCore gang
    if LocalPlayer.state.gang then
        return LocalPlayer.state.gang.name or 'Unknown'
    end
    
    -- Check for QBCore job
    if LocalPlayer.state.job then
        return TEAM_MAP[LocalPlayer.state.job.name] or 'Unknown'
    end
    
    return 'Unknown'
end

function RespawnPlayer(coords)
    if not Config.RESPAWN_AFTER_TELEPORT then return end
    
    local ambulanceSystem = Config.AMBULANCE_SYSTEM or "auto"
    
    -- Auto-detect ambulance system
    if ambulanceSystem == "auto" then
        if GetResourceState('wasabi_ambulance') == 'started' then
            ambulanceSystem = "wasabi"
        elseif GetResourceState('qb-ambulancejob') == 'started' then
            ambulanceSystem = "qb-ambulancejob"
        elseif GetResourceState('qb-core') == 'started' then
            ambulanceSystem = "qb-core"
        else
            ambulanceSystem = "none"
        end
    end
    
    -- Respawn using the appropriate system
    if ambulanceSystem == "wasabi" then
        -- Wasabi Ambulance
        if exports.wasabi_ambulance then
            exports.wasabi_ambulance:revivePlayer()
        elseif exports.wasabi_ambulance and exports.wasabi_ambulance.respawnPlayer then
            exports.wasabi_ambulance:respawnPlayer(coords.x, coords.y, coords.z)
        else
            -- Fallback to native respawn
            NetworkResurrectLocalPlayer(coords.x, coords.y, coords.z, 0.0, true, false)
            ClearPedBloodDamage(PlayerPedId())
            SetEntityHealth(PlayerPedId(), GetEntityMaxHealth(PlayerPedId()))
        end
    elseif ambulanceSystem == "qb-ambulancejob" then
        -- QB Ambulance Job
        if exports['qb-ambulancejob'] then
            if exports['qb-ambulancejob'].RevivePlayer then
                exports['qb-ambulancejob']:RevivePlayer()
            elseif exports['qb-ambulancejob'].respawnPlayer then
                exports['qb-ambulancejob']:respawnPlayer(coords)
            else
                TriggerEvent('hospital:client:Revive')
            end
        else
            -- Fallback to native respawn
            NetworkResurrectLocalPlayer(coords.x, coords.y, coords.z, 0.0, true, false)
            ClearPedBloodDamage(PlayerPedId())
            SetEntityHealth(PlayerPedId(), GetEntityMaxHealth(PlayerPedId()))
        end
    elseif ambulanceSystem == "qb-core" then
        -- QBCore basic respawn
        if exports['qb-core'] then
            local QBCore = exports['qb-core']:GetCoreObject()
            if QBCore.Functions.RevivePlayer then
                QBCore.Functions.RevivePlayer()
            else
                TriggerEvent('hospital:client:Revive')
            end
        else
            -- Fallback to native respawn
            NetworkResurrectLocalPlayer(coords.x, coords.y, coords.z, 0.0, true, false)
            ClearPedBloodDamage(PlayerPedId())
            SetEntityHealth(PlayerPedId(), GetEntityMaxHealth(PlayerPedId()))
        end
    elseif ambulanceSystem == "none" then
        -- Native FiveM respawn only
        NetworkResurrectLocalPlayer(coords.x, coords.y, coords.z, 0.0, true, false)
        ClearPedBloodDamage(PlayerPedId())
        SetEntityHealth(PlayerPedId(), GetEntityMaxHealth(PlayerPedId()))
    end
    
    -- Additional cleanup
    ClearPedTasksImmediately(PlayerPedId())
    SetPedCanRagdoll(PlayerPedId(), true)
end

function TeleportAwayFromVan()
    if not DoesEntityExist(van) then return end
    
    local ped = PlayerPedId()
    if not DoesEntityExist(ped) then return end
    
    local vanCoords = GetEntityCoords(van)
    
    -- Use random direction to teleport 500m away
    local angle = math.random(0, 360) * math.pi / 180
    local normalized = vector3(math.cos(angle), math.sin(angle), 0)
    
    -- Calculate target position 500m away from van
    local targetCoords = vanCoords + (normalized * TELEPORT_DISTANCE)
    
    -- Ensure Z coordinate is on ground
    local groundZ = targetCoords.z
    local found, z = GetGroundZFor_3dCoord(targetCoords.x, targetCoords.y, targetCoords.z + 100.0, false)
    if found then
        groundZ = z
    else
        -- If ground not found, use a safe height
        groundZ = targetCoords.z + 50.0
    end
    
    local finalCoords = vector3(targetCoords.x, targetCoords.y, groundZ + 1.0)
    
    -- Teleport player
    if IsEntityDead(ped) or IsPedDeadOrDying(ped, true) then
        NetworkResurrectLocalPlayer(finalCoords.x, finalCoords.y, finalCoords.z, 0.0, true, false)
    else
        SetEntityCoordsNoOffset(ped, finalCoords.x, finalCoords.y, finalCoords.z, false, false, false)
    end
    
    -- Respawn player using configured ambulance system
    Wait(100) -- Small delay to ensure teleport completed
    RespawnPlayer(finalCoords)
end

function DrawText2D(x, y, text, centered, scale)
    scale = scale or 0.42
    SetTextFont(4)
    SetTextScale(scale, scale)
    SetTextColour(255, 255, 255, 255) -- Clean white text like ox_lib
    SetTextCentre(centered or false)
    SetTextOutline()
    BeginTextCommandDisplayText("STRING")
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(x, y)
end

function CreateConfetti(entity)
    if not DoesEntityExist(entity) then return end
    
    local coords = GetEntityCoords(entity)
    local height = coords.z + 5.0
    
    -- Request particle effects
    RequestNamedPtfxAsset("scr_xs_celebration")
    while not HasNamedPtfxAssetLoaded("scr_xs_celebration") do
        Wait(10)
    end
    
    -- Create multiple confetti bursts
    CreateThread(function()
        for i = 1, 10 do
            Wait(200) -- Stagger the bursts
            
            -- Spawn confetti at different positions around the van
            local offsetX = (math.random() - 0.5) * 3.0
            local offsetY = (math.random() - 0.5) * 3.0
            local confettiCoords = vector3(coords.x + offsetX, coords.y + offsetY, height)
            
            -- Use confetti particle effect
            UseParticleFxNextCall("scr_xs_celebration")
            StartParticleFxNonLoopedAtCoord("scr_xs_confetti_burst", confettiCoords.x, confettiCoords.y, confettiCoords.z, 0.0, 0.0, 0.0, 1.0, false, false, false)
        end
        
        -- Also try alternative confetti effects
        Wait(500)
        for i = 1, 5 do
            Wait(300)
            local offsetX = (math.random() - 0.5) * 5.0
            local offsetY = (math.random() - 0.5) * 5.0
            local confettiCoords = vector3(coords.x + offsetX, coords.y + offsetY, height)
            
            -- Try different confetti effect
            UseParticleFxNextCall("scr_xs_celebration")
            StartParticleFxNonLoopedAtCoord("scr_xs_money_rain", confettiCoords.x, confettiCoords.y, confettiCoords.z, 0.0, 0.0, 0.0, 0.8, false, false, false)
        end
    end)
    
    -- Also add some explosion effects for visual flair (non-damaging)
    CreateThread(function()
        for i = 1, 3 do
            Wait(500)
            local offsetX = (math.random() - 0.5) * 2.0
            local offsetY = (math.random() - 0.5) * 2.0
            AddExplosion(coords.x + offsetX, coords.y + offsetY, height, 9, 0.1, true, false, false) -- Firework explosion type
        end
    end)
end

function DrawLeaderboard()
    if not leaderboardData or #leaderboardData == 0 then
        return
    end
    
    if not leaderboardData then
        leaderboardData = {}
    end
    
    local maxEntries = math.max(1, math.min(20, #leaderboardData)) -- Show top 20, minimum 1 for empty message
    local startX = 0.5
    local startY = 0.15 -- Top middle of screen
    local entryHeight = 0.032 -- Slightly smaller to fit more entries
    local bgWidth = 0.32 -- Wider box to fit player names better
    local bgHeight = 0.06 + (maxEntries * entryHeight) -- Dynamic height based on entries
    
    -- Background
    DrawRect(startX, startY, bgWidth, bgHeight, 0, 0, 0, 200)
    
    -- Border
    local borderThickness = 0.003
    DrawRect(startX, startY - bgHeight/2 + borderThickness/2, bgWidth, borderThickness, 100, 150, 255, 255) -- Top
    DrawRect(startX, startY + bgHeight/2 - borderThickness/2, bgWidth, borderThickness, 100, 150, 255, 255) -- Bottom
    DrawRect(startX - bgWidth/2 + borderThickness/2, startY, borderThickness, bgHeight, 100, 150, 255, 255) -- Left
    DrawRect(startX + bgWidth/2 - borderThickness/2, startY, borderThickness, bgHeight, 100, 150, 255, 255) -- Right
    
    -- Title
    local titleY = startY - bgHeight/2 + 0.025
    SetTextFont(4)
    SetTextScale(0.5, 0.5)
    SetTextColour(100, 150, 255, 255)
    SetTextCentre(true)
    SetTextOutline()
    BeginTextCommandDisplayText("STRING")
    AddTextComponentSubstringPlayerName("ASTRAL VAN HOLDS - LEADERBOARD")
    EndTextCommandDisplayText(startX, titleY)
    
    -- Header
    local headerY = startY - bgHeight/2 + 0.055
    SetTextFont(4)
    SetTextScale(0.35, 0.35)
    SetTextColour(200, 200, 200, 255)
    SetTextCentre(false)
    SetTextOutline()
    BeginTextCommandDisplayText("STRING")
    AddTextComponentSubstringPlayerName("#  PLAYER                          WINS")
    EndTextCommandDisplayText(startX - bgWidth/2 + 0.015, headerY)
    
    -- Entries
    if #leaderboardData == 0 then
        -- Show "No data" message
        local entryY = startY - bgHeight/2 + 0.08 + entryHeight
        SetTextFont(4)
        SetTextScale(0.35, 0.35)
        SetTextColour(200, 200, 200, 255)
        SetTextCentre(true)
        SetTextOutline()
        BeginTextCommandDisplayText("STRING")
        AddTextComponentSubstringPlayerName("No wins recorded yet!")
        EndTextCommandDisplayText(startX, entryY)
    else
        for i = 1, maxEntries do
            local entry = leaderboardData[i]
            if entry then
                local entryY = startY - bgHeight/2 + 0.08 + (i * entryHeight)
                
                -- Rank color (gold for 1st, silver for 2nd, bronze for 3rd)
                local r, g, b = 255, 255, 255
                if i == 1 then
                    r, g, b = 255, 215, 0 -- Gold
                elseif i == 2 then
                    r, g, b = 192, 192, 192 -- Silver
                elseif i == 3 then
                    r, g, b = 205, 127, 50 -- Bronze
                end
                
                -- Rank number
                SetTextFont(4)
                SetTextScale(0.35, 0.35)
                SetTextColour(r, g, b, 255)
                SetTextCentre(false)
                SetTextOutline()
                BeginTextCommandDisplayText("STRING")
                AddTextComponentSubstringPlayerName(string.format("%d.", i))
                EndTextCommandDisplayText(startX - bgWidth/2 + 0.015, entryY)
                
                -- Player name (truncate if too long)
                local displayName = entry.name
                if #displayName > 28 then
                    displayName = string.sub(displayName, 1, 25) .. "..."
                end
                
                SetTextFont(4)
                SetTextScale(0.35, 0.35)
                SetTextColour(r, g, b, 255)
                SetTextCentre(false)
                SetTextOutline()
                BeginTextCommandDisplayText("STRING")
                AddTextComponentSubstringPlayerName(displayName)
                EndTextCommandDisplayText(startX - bgWidth/2 + 0.05, entryY)
                
                -- Wins count
                SetTextFont(4)
                SetTextScale(0.35, 0.35)
                SetTextColour(r, g, b, 255)
                SetTextCentre(false)
                SetTextOutline()
                BeginTextCommandDisplayText("STRING")
                AddTextComponentSubstringPlayerName(tostring(entry.wins))
                EndTextCommandDisplayText(startX + bgWidth/2 - 0.015, entryY)
            end
        end
    end
    
    -- Footer (press ESC to close)
    local footerY = startY + bgHeight/2 - 0.02
    SetTextFont(4)
    SetTextScale(0.3, 0.3)
    SetTextColour(150, 150, 150, 255)
    SetTextCentre(true)
    SetTextOutline()
    BeginTextCommandDisplayText("STRING")
    AddTextComponentSubstringPlayerName("Press [ESC] to close")
    EndTextCommandDisplayText(startX, footerY)
end

function DrawKillFeed()
    if not killFeedText then return end
    
    local startX = 0.5
    local startY = 0.12
    local bgWidth = 0.25
    local bgHeight = 0.04
    
    -- Background
    DrawRect(startX, startY, bgWidth, bgHeight, 0, 0, 0, 200)
    
    -- Border
    local borderThickness = 0.002
    DrawRect(startX, startY - bgHeight/2 + borderThickness/2, bgWidth, borderThickness, 255, 0, 0, 255) -- Top (red)
    DrawRect(startX, startY + bgHeight/2 - borderThickness/2, bgWidth, borderThickness, 255, 0, 0, 255) -- Bottom (red)
    DrawRect(startX - bgWidth/2 + borderThickness/2, startY, borderThickness, bgHeight, 255, 0, 0, 255) -- Left (red)
    DrawRect(startX + bgWidth/2 - borderThickness/2, startY, borderThickness, bgHeight, 255, 0, 0, 255) -- Right (red)
    
    -- Kill feed text
    SetTextFont(4)
    SetTextScale(0.4, 0.4)
    SetTextColour(255, 100, 100, 255) -- Red tint
    SetTextCentre(true)
    SetTextOutline()
    BeginTextCommandDisplayText("STRING")
    AddTextComponentSubstringPlayerName(killFeedText)
    EndTextCommandDisplayText(startX, startY)
end

