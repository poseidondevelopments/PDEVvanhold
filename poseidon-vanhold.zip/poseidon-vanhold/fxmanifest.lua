fx_version 'cerulean'
game 'gta5'

author 'POSEIDON DEVELOPMENTS'
description 'Hold The Van Event'
version '1.1.0'

shared_script '@ox_lib/init.lua'
shared_script 'config.lua'
client_script 'client/client.lua'
server_script 'server/server.lua'

ui_page 'html/index.html'

files {
    'data/stats.json',
    'data/streaks.json',
    'html/index.html',
    'html/style.css',
    'html/script.js'
}

dependencies {
    'ox_lib'
}