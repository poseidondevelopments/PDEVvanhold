fx_version 'cerulean'
game 'gta5'

author 'POSEIDON DEVELOPMENTS'
description 'Hold The Van Event'
version '1.1.0'

shared_script '@ox_lib/init.lua'
shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'

-- Data persistence files
files {
    'stats.json',
    'streaks.json'
}

dependencies {
    'ox_lib'
}

-- NOTE: For the respawn system to work, you must have one of the following ambulance scripts installed:
-- - wasabi_ambulance (for Wasabi Ambulance)
-- - qb-ambulancejob (for QB Ambulance Job)
-- - qb-core (for QBCore basic respawn)
-- The script will auto-detect which system you're using, or you can manually set Config.AMBULANCE_SYSTEM in config.lua
