(function(){
  let visible = false;

  // Elements
  const root = document.getElementById('claim-ui');
  const elText = document.getElementById('claim-text');
  const elTimer = document.getElementById('claim-timer');
  const killfeed = document.getElementById('killfeed');
  const killfeedMessages = document.getElementById('killfeed-messages');
  const statsScreen = document.getElementById('stats-screen');
  const statsTableBody = document.getElementById('stats-table-body');

  let killfeedVisible = false;
  let statsVisible = false;

  // Public API via NUI postMessage
  window.addEventListener('message', (event) => {
    const d = event.data || {};
    switch(d.action){
      case 'showUI':
        showUI(d);
        break;
      case 'hideUI':
        hideUI();
        break;
      case 'updateTimer':
        if (elTimer && d.time) {
          elTimer.textContent = d.time;
        }
        break;
      case 'updateClaimer':
      case 'setClaimer':
      case 'setCharacterName':
        setClaimer(d.claimer || d.name || '', d.isYou);
        break;
      case 'updateInstruction':
        // Instructions not displayed in simple UI, but handle to prevent errors
        break;
      case 'addKill':
        addKillMessage(d.killer, d.victim, d.weapon);
        break;
      case 'showKillfeed':
        showKillfeed();
        break;
      case 'hideKillfeed':
        hideKillfeed();
        break;
      case 'showStats':
        showStats(d.stats || []);
        break;
      case 'hideStats':
        hideStats();
        break;
    }
  });

  function showUI(d){
    if(!visible){
      root.classList.remove('hidden');
      root.classList.add('fade-in');
      visible = true;
    }
    if (d && (d.claimer || d.name)) setClaimer(d.claimer || d.name, d.isYou);
  }

  function hideUI(){
    if(visible){
      root.classList.remove('fade-in');
      root.classList.add('fade-out');
      setTimeout(() => {
        root.classList.add('hidden');
        root.classList.remove('fade-out');
      }, 200);
      visible = false;
    }
  }

  function setClaimer(name, isYou){
    const clean = (name || '').trim();

    if (clean && clean !== 'null' && clean !== 'undefined' && clean.length > 0){
      if (isYou) {
        elText.textContent = 'You Hold The Van!';
      } else {
        elText.textContent = `${clean} Holds The Van!`;
      }
    } else {
      elText.textContent = 'Unclaimed';
    }
  }

  function showKillfeed(){
    if (!killfeedVisible) {
      killfeedVisible = true;
      killfeed.classList.remove('hidden');
    }
  }

  function hideKillfeed(){
    killfeedVisible = false;
    killfeed.classList.add('hidden');
    setTimeout(() => {
      killfeedMessages.innerHTML = '';
    }, 300);
  }

  function addKillMessage(killer, victim, weapon){
    if (!killfeedVisible) {
      showKillfeed();
    }

    const messageDiv = document.createElement('div');
    messageDiv.className = 'killfeed-message';

    messageDiv.innerHTML = `
      <span class="killer">${killer || 'Unknown'}</span>
      <i class="fa-solid fa-gun kill-icon"></i>
      <span class="victim">${victim || 'Unknown'}</span>
    `;

    killfeedMessages.insertBefore(messageDiv, killfeedMessages.firstChild);

    // Limit messages (default 8, could be made configurable)
    const maxMessages = 8;
    while (killfeedMessages.children.length > maxMessages) {
      killfeedMessages.removeChild(killfeedMessages.lastChild);
    }

    // Auto-remove after 8 seconds (could be made configurable)
    const fadeTime = 8000;
    setTimeout(() => {
      if (messageDiv.parentNode) {
        messageDiv.style.opacity = '0';
        messageDiv.style.transform = 'translateX(50px)';
        setTimeout(() => {
          if (messageDiv.parentNode) {
            messageDiv.parentNode.removeChild(messageDiv);
          }
        }, 300);
      }
    }, fadeTime);
  }

  function showStats(stats){
    if (!statsScreen || !statsTableBody) {
      console.error('[STATS] Stats screen or table body not found!');
      return;
    }
    
    console.log('[STATS] Showing stats screen with', stats.length, 'players');
    
    // Clear previous stats
    statsTableBody.innerHTML = '';
    
    // Populate stats table
    stats.forEach((player, index) => {
      const row = document.createElement('div');
      row.className = 'stats-table-row';
      
      // Highlight top player
      if (index === 0 && player.kills > 0) {
        row.classList.add('top-player');
      }
      
      row.innerHTML = `
        <div class="stats-rank">${index + 1}</div>
        <div class="stats-player">${player.name}</div>
        <div class="stats-kills">${player.kills}</div>
        <div class="stats-deaths">${player.deaths}</div>
        <div class="stats-kd">${player.kd}</div>
      `;
      
      statsTableBody.appendChild(row);
    });
    
    // Show stats screen
    statsScreen.classList.remove('hidden');
    statsVisible = true;
    
    console.log('[STATS] Stats screen is now visible');
    
    // Auto-hide after 10 seconds (reduced from 15)
    setTimeout(() => {
      hideStats();
    }, 10000);
  }
  
  function hideStats(){
    if (!statsVisible) return;
    
    console.log('[STATS] Hiding stats screen');
    
    if (statsScreen) {
      statsScreen.classList.add('hidden');
    }
    statsVisible = false;
    
    // Notify game (callback still exists but does nothing now)
    fetch(`https://${GetParentResourceName()}/closeStats`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({})
    }).catch(() => {}); // Silently catch any errors
    
    // Clear stats data after animation
    setTimeout(() => {
      if (statsTableBody) {
        statsTableBody.innerHTML = '';
      }
    }, 300);
  }
  
  // Helper to get resource name
  function GetParentResourceName() {
    return window.location.hostname === '' ? 'poseidon-vanhold' : window.location.hostname;
  }

  // Expose helpers for local testing if needed
  window.__claimUI = { showUI, hideUI, setClaimer, addKillMessage, showKillfeed, hideKillfeed, showStats, hideStats };
})();

