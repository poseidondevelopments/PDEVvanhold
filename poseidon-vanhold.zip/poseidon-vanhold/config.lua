-- =====================
-- Van Hold Event - Config
-- =====================

Config = Config or {}

-- Van Spawn Locations (editable)
Config.VAN_LOCATIONS = {
    {
        name = "Airport",
        coords = vector3(-1337.31, -3044.04, 13.94),
        heading = 0.0,
        holdTime = 720  -- Custom hold time in seconds for this location (optional, defaults to Config.DEFAULT_HOLD_TIME)
    },
    {
        name = "Sandy Airport",
        coords = vector3(1349.92, 3119.38, 41.33),
        heading = 0.0,
        holdTime = 600  -- Custom hold time in seconds for this location (optional, defaults to Config.DEFAULT_HOLD_TIME)
    },
    {
        name = "Observatory",
        coords = vector3(-401.83, 1207.85, 325.95),
        heading = 0.0,
        holdTime = 550  -- Custom hold time in seconds for this location (optional, defaults to Config.DEFAULT_HOLD_TIME)
    },
    {
        name = "Military Base",
        coords = vector3(-2449.45, 3172.47, 32.96),
        heading = 0.0,
        holdTime = 680  -- Custom hold time in seconds for this location (optional, defaults to Config.DEFAULT_HOLD_TIME)
    },
    {
        name = "Paleto Bay 031",
        coords = vector3(97.40, 6916.50, 20.96),
        heading = 0.0,
        holdTime = 620  -- Custom hold time in seconds for this location (optional, defaults to Config.DEFAULT_HOLD_TIME)
    },
    {
        name = "Grapeseed 119",
        coords = vector3(2018.29, 4889.54, 42.73),
        heading = 0.0,
        holdTime = 570  -- Custom hold time in seconds for this location (optional, defaults to Config.DEFAULT_HOLD_TIME)
    },
    -- Add more locations here:
    -- {
    --     name = "Location Name",
    --     coords = vector3(x, y, z),
    --     heading = 0.0,
    --     holdTime = 60  -- Optional: custom hold time for this location
    -- },
}

-- Default hold time (used if location doesn't specify holdTime)
Config.DEFAULT_HOLD_TIME = 800  -- Time in seconds required to hold the van

-- Blip Settings (editable)
Config.BLIP_SETTINGS = {
    vanSprite = 67,           -- Blip sprite for the van (67 = van icon)
    vanColor = 5,             -- Blip color for the van (5 = yellow, see FiveM blip colors)
    vanScale = 1.2,           -- Blip scale for the van
    zoneColor = 1,            -- Blip color for the hold zone (1 = red)
    zoneAlpha = 120,          -- Blip alpha/transparency for the hold zone (0-255)
    zoneScale = 1.0           -- Blip scale for the hold zone
}

-- Streak System Settings (editable)
Config.STREAK_ENABLED = true  -- Set to false to disable streak system
Config.STREAK_BONUS_LOOT = {  -- Bonus items given for consecutive wins
    -- Format: {streak = number, items = {{item = "item_name", minCount = min, maxCount = max, chance = percentage}}}
    {streak = 2, items = {{item = "black_money", minCount = 50000, maxCount = 100000, chance = 100}}},
    {streak = 3, items = {{item = "black_money", minCount = 100000, maxCount = 200000, chance = 100}}},
    {streak = 5, items = {{item = "black_money", minCount = 200000, maxCount = 300000, chance = 100}, {item = "weapon_appistol", minCount = 1, maxCount = 1, chance = 50}}},
    -- Add more streak rewards here
}

-- Loot Pool (editable) - Items given to winner
Config.LOOT_POOL = {
    -- Format: {item = "item_name", minCount = min_amount, maxCount = max_amount, chance = percentage, minItems = min_selections, maxItems = max_selections}
    -- chance: 0-100 (percentage chance the item will be granted when selected)
    -- minItems/maxItems: How many times this item can be selected (if it passes chance roll)
    -- Example:
    {item = "black_money", minCount = 100000, maxCount = 200000, chance = 100, minItems = 1, maxItems = 1},
    {item = "ammo-9", minCount = 100, maxCount = 200, chance = 75, minItems = 1, maxItems = 3},
    {item = "weapon_appistol", minCount = 1, maxCount = 1, chance = 50, minItems = 0, maxItems = 1},
    -- Add your loot items here
    -- Note: If you want fixed count, set minCount and maxCount to the same value
    -- Note: chance = 100 means always granted, chance = 50 means 50% chance, etc.
    -- Note: minItems/maxItems control how many times this specific item can be selected (0 means it might not be selected at all)
}

-- Auto-Spawn Settings (editable)
Config.AUTO_SPAWN_ENABLED = true  -- Set to false to disable automatic spawning
Config.AUTO_SPAWN_INTERVAL = 60   -- Time in minutes between automatic van spawns (e.g., 60 = 1 hour, 120 = 2 hours, 10 = 10 minutes)
Config.PRE_EVENT_ANNOUNCEMENT = true  -- Set to true to show countdown notifications before auto-spawn events
Config.ANNOUNCEMENT_TIME = 2  -- Time in minutes before event to start showing announcements (e.g., 5 = 5 minutes before)

-- Ambulance System Settings (editable)
Config.AMBULANCE_SYSTEM = "auto"  -- Options: "auto" (auto-detect), "wasabi", "qb-ambulancejob", "qb-core", "none"
Config.RESPAWN_AFTER_TELEPORT = true  -- Set to true to respawn player after teleportation

