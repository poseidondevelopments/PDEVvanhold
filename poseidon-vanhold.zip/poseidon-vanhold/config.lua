-- =====================
-- Van Hold Event - Config
-- =====================

Config = Config or {}

-- Van Spawn Locations (editable)
Config.VAN_LOCATIONS = {
    {
        name = "Airport",
        coords = vector3(-1337.31, -3044.04, 13.94),
        heading = 0.0,
        holdTime = 900  -- Custom hold time in seconds for this location (optional, defaults to Config.DEFAULT_HOLD_TIME)
    },
    {
        name = "Sandy Airport",
        coords = vector3(1349.92, 3119.38, 41.33),
        heading = 0.0,
        holdTime = 900  
    },
    {
        name = "Observatory",
        coords = vector3(-401.83, 1207.85, 325.95),
        heading = 0.0,
        holdTime = 900  
    },
    {
        name = "Military Base",
        coords = vector3(-2449.45, 3172.47, 32.96),
        heading = 0.0,
        holdTime = 900  
    },
    {
        name = "Paleto Bay",
        coords = vector3(97.40, 6916.50, 20.96),
        heading = 0.0,
        holdTime = 900  
    },
    {
        name = "Grapeseed",
        coords = vector3(2018.29, 4889.54, 42.73),
        heading = 0.0,
        holdTime = 900
    },
    {
        name = "Wind Farm",
        coords = vector3(2211.99, 2062.83, 132.31),
        heading = 0.0,
        holdTime = 900  
    },
    {
        name = "Power Station",
        coords = vector3(2725.21, 1361.85, 24.51),
        heading = 0.0,
        holdTime = 900  
    },
    {
        name = "Redwood Lights",
        coords = vector3(1070.70, 2361.85, 43.96),
        heading = 0.0,
        holdTime = 900  
    },
    {
        name = "Alturist Camp",
        coords = vector3(-1154.75, 4922.83, 221.98),
        heading = 0.0,
        holdTime = 900  
    },
    {
        name = "Docks",
        coords = vector3(1021.29, -3185.90, 5.90),
        heading = 0.0,
        holdTime = 900  
    },
    {
        name = "Oil Fields",
        coords = vector3(1517.93, -2100.13, 76.81),
        heading = 0.0,
        holdTime = 900  
    },
    {
        name = "Kortz Center",
        coords = vector3(-2237.52, 266.84, 174.61),
        heading = 0.0,
        holdTime = 900  
    },
    -- Add more locations here:
    -- {
    --     name = "Location Name",
    --     coords = vector3(x, y, z),
    --     heading = 0.0,
    --     holdTime = 60  -- Optional: custom hold time for this location
    -- },
}

-- Event duration (how long the event lasts in minutes)
Config.EVENT_DURATION = 15  -- Event duration in minutes (whoever is holding when event ends wins)

-- Redzone Blip Settings (editable)
Config.RedzoneBlip = {
    sprite = 67,
    color = 1,
    scale = 1.2,
    radius = 250.0  -- Radius of the redzone blip on the map (in meters)
}

-- Streak System Settings (editable)
Config.STREAK_ENABLED = true  -- Set to false to disable streak system
Config.STREAK_BONUS_LOOT = {  -- Bonus items given for consecutive wins
    -- Format: {streak = number, items = {{item = "item_name", minCount = min, maxCount = max, chance = percentage}}}
    {streak = 2, items = {{item = "dirtymoney", minCount = 50000, maxCount = 100000, chance = 100}}},
    {streak = 3, items = {{item = "dirtymoney", minCount = 100000, maxCount = 200000, chance = 100}}},
    {streak = 5, items = {{item = "dirtymoney", minCount = 200000, maxCount = 300000, chance = 100}, {item = "weapon_appistol", minCount = 1, maxCount = 1, chance = 50}}},
    -- Add more streak rewards here
}

-- Loot Pool (editable) - Items given to winner
Config.LOOT_POOL = {
    -- Format: {item = "item_name", minCount = min_amount, maxCount = max_amount, chance = percentage, minItems = min_selections, maxItems = max_selections}
    -- chance: 0-100 (percentage chance the item will be granted when selected)
    -- minItems/maxItems: How many times this item can be selected (if it passes chance roll)
    -- Example:
    {item = "dirtymoney", minCount = 100000, maxCount = 200000, chance = 100, minItems = 1, maxItems = 1},
    {item = "ammo-9", minCount = 100, maxCount = 200, chance = 75, minItems = 1, maxItems = 1},
    {item = "weapon_appistol", minCount = 1, maxCount = 1, chance = 30, minItems = 1, maxItems = 1},
    {item = "weapon_pistol50", minCount = 1, maxCount = 1, chance = 50, minItems = 1, maxItems = 1},
    {item = "bobcatkeycard", minCount = 1, maxCount = 1, chance = 50, minItems = 1, maxItems = 1},
    {item = "combat_booster", minCount = 5, maxCount = 10, chance = 50, minItems = 1, maxItems = 1},
    {item = "armour", minCount = 3, maxCount = 7, chance = 50, minItems = 1, maxItems = 1},
    {item = "usbhazard", minCount = 1, maxCount = 2, chance = 20, minItems = 1, maxItems = 1},
    -- Add your loot items here
    -- Note: If you want fixed count, set minCount and maxCount to the same value
    -- Note: chance = 100 means always granted, chance = 50 means 50% chance, etc.
    -- Note: minItems/maxItems control how many times this specific item can be selected (0 means it might not be selected at all)
}

-- Auto-Spawn Settings (editable)
Config.AUTO_SPAWN_ENABLED = true  -- Set to false to disable automatic spawning
Config.AUTO_SPAWN_INTERVAL = 60   -- Time in minutes between automatic van spawns (e.g., 60 = 1 hour, 120 = 2 hours, 10 = 10 minutes)
Config.PRE_EVENT_ANNOUNCEMENT = true  -- Set to true to show countdown notifications before auto-spawn events
Config.ANNOUNCEMENT_TIME = 2  -- Time in minutes before event to start showing announcements (e.g., 5 = 5 minutes before)

-- Debug Settings (editable)
Config.DEBUG_MODE = false  -- Set to true to enable debug messages in console (useful for troubleshooting)

