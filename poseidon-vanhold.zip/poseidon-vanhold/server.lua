-- =====================
-- Van Hold Event - Server
-- =====================

local TEAM_MAP = {
    police = 'Police',
    sheriff = 'Sheriff',
    ambulance = 'EMS'
}


local EventActive = false
local VanHolder = nil
local HolderTeam = nil
local HoldTime = 0
local MaxHoldTime = 800
local WinnerDeclared = false
local deadPlayers = {}
local EventStartTime = 0
local COUNTDOWN_DURATION = 20000 -- 5 seconds
local COUNTDOWN_DELAY = 5000 -- 5 seconds delay before countdown starts
local EVENT_TIMEOUT = 1200 -- 20 minutes in seconds (20 * 60)

-- Event Statistics
local EventStats = {
    totalEvents = 0,
    totalWins = {},
    longestHoldTime = 0,
    longestHolder = nil,
    mostWins = 0,
    mostWinsPlayer = nil
}

-- Streak System
local PlayerStreaks = {}  -- Track consecutive wins per player

-- =====================
-- Data Persistence with Local Caching
-- =====================

local STATS_FILE = GetResourcePath(GetCurrentResourceName()) .. "/stats.json"
local STREAKS_FILE = GetResourcePath(GetCurrentResourceName()) .. "/streaks.json"

-- Cache state tracking
local CacheState = {
    statsDirty = false,      -- Track if stats need to be saved
    streaksDirty = false,    -- Track if streaks need to be saved
    lastSaveTime = 0,        -- Last time data was saved to disk
    saveInterval = 30000     -- Save interval in milliseconds (30 seconds)
}

local function LoadStats()
    local file = LoadResourceFile(GetCurrentResourceName(), "stats.json")
    if file then
        local data = json.decode(file)
        if data then
            EventStats = data
            -- Convert player IDs from strings to numbers if needed
            if EventStats.totalWins then
                local newWins = {}
                for k, v in pairs(EventStats.totalWins) do
                    newWins[tonumber(k) or k] = v
                end
                EventStats.totalWins = newWins
            end
            if EventStats.longestHolder then
                EventStats.longestHolder = tonumber(EventStats.longestHolder) or EventStats.longestHolder
            end
            if EventStats.mostWinsPlayer then
                EventStats.mostWinsPlayer = tonumber(EventStats.mostWinsPlayer) or EventStats.mostWinsPlayer
            end
        end
    end
    -- Reset dirty flag after loading
    CacheState.statsDirty = false
end

local function SaveStats(force)
    -- Mark as dirty (needs saving)
    CacheState.statsDirty = true
    
    -- If force is true, save immediately (for critical events)
    if force then
        local data = json.encode(EventStats)
        SaveResourceFile(GetCurrentResourceName(), "stats.json", data, -1)
        CacheState.statsDirty = false
        CacheState.lastSaveTime = GetGameTimer()
    end
end

local function LoadStreaks()
    local file = LoadResourceFile(GetCurrentResourceName(), "streaks.json")
    if file then
        local data = json.decode(file)
        if data then
            -- Convert player IDs from strings to numbers if needed
            local newStreaks = {}
            for k, v in pairs(data) do
                newStreaks[tonumber(k) or k] = v
            end
            PlayerStreaks = newStreaks
        end
    end
    -- Reset dirty flag after loading
    CacheState.streaksDirty = false
end

local function SaveStreaks(force)
    -- Mark as dirty (needs saving)
    CacheState.streaksDirty = true
    
    -- If force is true, save immediately (for critical events)
    if force then
        local data = json.encode(PlayerStreaks)
        SaveResourceFile(GetCurrentResourceName(), "streaks.json", data, -1)
        CacheState.streaksDirty = false
        CacheState.lastSaveTime = GetGameTimer()
    end
end

-- Periodic cache flush to disk
CreateThread(function()
    while true do
        Wait(CacheState.saveInterval) -- Wait for save interval
        
        local currentTime = GetGameTimer()
        local timeSinceLastSave = currentTime - CacheState.lastSaveTime
        local saved = false
        
        -- Save stats if dirty and enough time has passed
        if CacheState.statsDirty and timeSinceLastSave >= CacheState.saveInterval then
            local data = json.encode(EventStats)
            SaveResourceFile(GetCurrentResourceName(), "stats.json", data, -1)
            CacheState.statsDirty = false
            saved = true
        end
        
        -- Save streaks if dirty and enough time has passed
        if CacheState.streaksDirty and timeSinceLastSave >= CacheState.saveInterval then
            local data = json.encode(PlayerStreaks)
            SaveResourceFile(GetCurrentResourceName(), "streaks.json", data, -1)
            CacheState.streaksDirty = false
            saved = true
        end
        
        -- Update last save time if any save occurred
        if saved then
            CacheState.lastSaveTime = currentTime
        end
    end
end)

-- Save all cached data on resource stop
AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        -- Force save all dirty data before resource stops
        if CacheState.statsDirty then
            local data = json.encode(EventStats)
            SaveResourceFile(GetCurrentResourceName(), "stats.json", data, -1)
        end
        if CacheState.streaksDirty then
            local data = json.encode(PlayerStreaks)
            SaveResourceFile(GetCurrentResourceName(), "streaks.json", data, -1)
        end
    end
end)

-- Load data on server start
LoadStats()
LoadStreaks()

-- =====================
-- Event Start Function
-- =====================

local function StartVanEvent(adminSource)
    if EventActive then
        if adminSource then
            TriggerClientEvent('chat:addMessage', adminSource, {
                color = {255, 255, 0},
                args = {"System", "Van Hold event is already active!"}
            })
        end
        return false
    end

    EventActive = true
    HoldTime = 0
    VanHolder = nil
    HolderTeam = nil
    WinnerDeclared = false
    deadPlayers = {}
    EventStartTime = GetGameTimer()

    -- Select random location from Config.VAN_LOCATIONS
    local selectedLocation = nil
    if #Config.VAN_LOCATIONS > 0 then
        local randomIndex = math.random(1, #Config.VAN_LOCATIONS)
        selectedLocation = Config.VAN_LOCATIONS[randomIndex]
    else
        -- Fallback to admin's location if no locations defined
        if adminSource then
            local adminPed = GetPlayerPed(adminSource)
            selectedLocation = {
                name = "Admin Location",
                coords = GetEntityCoords(adminPed),
                heading = GetEntityHeading(adminPed),
                holdTime = Config.DEFAULT_HOLD_TIME or 40
            }
        else
            -- If no admin source and no locations, use default
            selectedLocation = {
                name = "Default Location",
                coords = vector3(0.0, 0.0, 0.0),
                heading = 0.0,
                holdTime = Config.DEFAULT_HOLD_TIME or 40
            }
        end
    end

    -- Set custom hold time for this event (from location config or default)
    MaxHoldTime = selectedLocation.holdTime or Config.DEFAULT_HOLD_TIME or 40

    -- Update statistics
    EventStats.totalEvents = EventStats.totalEvents + 1
    SaveStats() -- Save after updating total events (cached, will save periodically)
    
    TriggerClientEvent('van:spawn', -1, selectedLocation.coords.x, selectedLocation.coords.y, selectedLocation.coords.z, selectedLocation.heading, selectedLocation.name)
    TriggerClientEvent('van:eventStarted', -1, MaxHoldTime, selectedLocation.name, EventStats.totalEvents)
    
    if adminSource then
        -- Admin manually started the event
        TriggerClientEvent('chat:addMessage', adminSource, {
            color = {0, 255, 0},
            args = {"System", "Van Hold event started!"}
        })
    else
        -- Auto-spawned event
        TriggerClientEvent('chat:addMessage', -1, {
            color = {100, 150, 255},
            args = {"ASTRAL VAN HOLDS", "Van Hold event has started automatically!"}
        })
    end
    
    return true
end

-- =====================
-- Commands
-- =====================

RegisterCommand('startvan', function(source)
    -- Check if player has admin permissions
    if not IsPlayerAceAllowed(source, "command.startvan") then
        TriggerClientEvent('chat:addMessage', source, {
            color = {255, 0, 0},
            args = {"System", "You do not have permission to use this command."}
        })
        return
    end
    
    StartVanEvent(source)
end, true)

RegisterCommand('stopvan', function()
    EventActive = false
    HoldTime = 0
    VanHolder = nil
    HolderTeam = nil
    WinnerDeclared = false
    deadPlayers = {}

    TriggerClientEvent('van:eventStopped', -1)
    TriggerClientEvent('van:cleanup', -1)
end, true)

RegisterCommand('vanstats', function(source)
    local longestHolderName = "None"
    if EventStats.longestHolder then
        longestHolderName = GetPlayerName(EventStats.longestHolder) or "Unknown"
    end
    
    local mostWinsName = "None"
    if EventStats.mostWinsPlayer then
        mostWinsName = GetPlayerName(EventStats.mostWinsPlayer) or "Unknown"
    end
    
    local totalWinsCount = 0
    for _, wins in pairs(EventStats.totalWins) do
        totalWinsCount = totalWinsCount + wins
    end
    
    TriggerClientEvent('chat:addMessage', source, {
        color = {100, 150, 255},
        multiline = true,
        args = {"ASTRAL VAN HOLDS - STATISTICS", string.format("Total Events: %d\nTotal Wins: %d\nLongest Hold Time: %d seconds (%s)\nMost Wins: %d (%s)", 
            EventStats.totalEvents, 
            totalWinsCount,
            EventStats.longestHoldTime,
            longestHolderName,
            EventStats.mostWins,
            mostWinsName
        )}
    })
end, false)

RegisterCommand('vanleaderboard', function(source)
    -- Build leaderboard data
    local leaderboardData = {}
    
    for playerId, wins in pairs(EventStats.totalWins) do
        if wins and wins > 0 then
            local playerName = GetPlayerName(playerId) or "Unknown"
            table.insert(leaderboardData, {
                name = playerName,
                wins = wins,
                playerId = playerId
            })
        end
    end
    
    -- Sort by wins (descending)
    table.sort(leaderboardData, function(a, b)
        return a.wins > b.wins
    end)
    
    -- If no data, send empty table with a message
    if #leaderboardData == 0 then
        table.insert(leaderboardData, {
            name = "No wins yet!",
            wins = 0,
            playerId = nil
        })
    end
    
    -- Send to client
    TriggerClientEvent('van:showLeaderboard', source, leaderboardData)
end, false)

-- =====================
-- Holder Management
-- =====================

RegisterNetEvent('van:setHolder', function(team, isAlive)
    local src = source
    
    if not EventActive or WinnerDeclared then return end
    if not isAlive then return end
    if deadPlayers[src] then return end
    if VanHolder and VanHolder ~= src then return end
    
    -- Check if countdown is still active (delay + countdown duration)
    if GetGameTimer() - EventStartTime < (COUNTDOWN_DELAY + COUNTDOWN_DURATION) then return end

    VanHolder = src
    HolderTeam = team
    
    -- Get gang/job info for holder - check gang first, then job
    local holderGang = nil
    if GetResourceState('qb-core') == 'started' then
        local QBCore = exports['qb-core']:GetCoreObject()
        local Player = QBCore.Functions.GetPlayer(src)
        if Player then
            -- Check for gang first
            if Player.PlayerData.gang and Player.PlayerData.gang.name and Player.PlayerData.gang.name ~= "" then
                holderGang = Player.PlayerData.gang.name
            -- If no gang, check for job via QBCore
            elseif Player.PlayerData.job and Player.PlayerData.job.name and Player.PlayerData.job.name ~= "" then
                -- Use TEAM_MAP if available, otherwise use the job name directly
                holderGang = TEAM_MAP[Player.PlayerData.job.name] or Player.PlayerData.job.name
            end
        end
    end
    
    TriggerClientEvent('van:updateHolder', -1, VanHolder, HolderTeam, holderGang)
    -- Send current timer when new holder takes over
    TriggerClientEvent('van:updateTimer', -1, HoldTime)
end)

RegisterNetEvent('van:clearHolder', function()
    local src = source
    
    if not EventActive then return end
    if VanHolder ~= src then return end

    VanHolder = nil
    HolderTeam = nil
    TriggerClientEvent('van:updateHolder', -1, nil, nil, nil)
end)

-- =====================
-- Death Management
-- =====================

RegisterNetEvent('playerDied', function()
    local src = source
    deadPlayers[src] = true

    if VanHolder == src then
        VanHolder = nil
        HolderTeam = nil
        -- Reset timer when holder dies
        HoldTime = 0
        TriggerClientEvent('van:updateHolder', -1, nil, nil)
        TriggerClientEvent('van:updateTimer', -1, HoldTime)
    end
end)

RegisterNetEvent('playerRespawned', function()
    local src = source
    deadPlayers[src] = nil
end)

-- =====================
-- Timer & Win Condition
-- =====================

CreateThread(function()
    while true do
        Wait(1000)
        
        if EventActive and not WinnerDeclared then
            -- Check if 20 minutes have passed with no holder
            local timeSinceStart = (GetGameTimer() - EventStartTime) / 1000 -- Convert to seconds
            if not VanHolder and timeSinceStart >= EVENT_TIMEOUT then
                -- Event timeout - no one claimed the van in 20 minutes
                EventActive = false
                WinnerDeclared = true
                
                TriggerClientEvent('chat:addMessage', -1, {
                    color = {255, 165, 0},
                    args = {"ASTRAL VAN HOLDS", "Van Hold event ended - No one claimed the van in time!"}
                })
                
                TriggerClientEvent('van:eventStopped', -1)
                TriggerClientEvent('van:cleanup', -1)
                
                -- Reset variables
                HoldTime = 0
                VanHolder = nil
                HolderTeam = nil
                deadPlayers = {}
                
                -- Reset all streaks when event times out (no winner)
                if Config.STREAK_ENABLED then
                    for playerId, _ in pairs(PlayerStreaks) do
                        PlayerStreaks[playerId] = 0
                    end
                    SaveStreaks(true) -- Force save on timeout (important state change)
                end
            elseif VanHolder then
                if deadPlayers[VanHolder] then
                    VanHolder = nil
                    HolderTeam = nil
                    -- Reset timer when holder dies
                    HoldTime = 0
                    TriggerClientEvent('van:updateHolder', -1, nil, nil)
                    TriggerClientEvent('van:updateTimer', -1, HoldTime)
                else
                    HoldTime = HoldTime + 1
                    TriggerClientEvent('van:updateTimer', -1, HoldTime)

                    if HoldTime >= MaxHoldTime then
                        WinnerDeclared = true
                        EventActive = false
                        
                        -- Get winner name and team/gang for announcement
                        local winnerName = GetPlayerName(VanHolder) or "Unknown"
                        local winnerTeam = HolderTeam or "Unknown"
                    
                    -- Get gang/job info if available (QBCore) - check gang first, then job
                    local winnerRole = nil
                    if GetResourceState('qb-core') == 'started' then
                        local QBCore = exports['qb-core']:GetCoreObject()
                        local Player = QBCore.Functions.GetPlayer(VanHolder)
                        if Player then
                            -- Check for gang first
                            if Player.PlayerData.gang and Player.PlayerData.gang.name then
                                winnerRole = Player.PlayerData.gang.name
                            -- If no gang, check for job
                            elseif Player.PlayerData.job and Player.PlayerData.job.name then
                                winnerRole = TEAM_MAP[Player.PlayerData.job.name] or Player.PlayerData.job.name
                            end
                        end
                    end
                    
                    -- Update statistics
                    if not EventStats.totalWins[VanHolder] then
                        EventStats.totalWins[VanHolder] = 0
                    end
                    EventStats.totalWins[VanHolder] = EventStats.totalWins[VanHolder] + 1
                    
                    -- Track longest hold time
                    if HoldTime > EventStats.longestHoldTime then
                        EventStats.longestHoldTime = HoldTime
                        EventStats.longestHolder = VanHolder
                    end
                    
                    -- Track most wins
                    if EventStats.totalWins[VanHolder] > EventStats.mostWins then
                        EventStats.mostWins = EventStats.totalWins[VanHolder]
                        EventStats.mostWinsPlayer = VanHolder
                    end
                    
                    -- Save stats after update (force save on win - critical event)
                    SaveStats(true)
                    
                    -- Streak System: Track consecutive wins
                    local currentStreak = 1
                    if Config.STREAK_ENABLED then
                        if not PlayerStreaks[VanHolder] then
                            PlayerStreaks[VanHolder] = 0
                        end
                        -- Increment streak (consecutive win)
                        PlayerStreaks[VanHolder] = PlayerStreaks[VanHolder] + 1
                        currentStreak = PlayerStreaks[VanHolder]
                        
                        -- Reset streaks for all other players (they didn't win)
                        for playerId, _ in pairs(PlayerStreaks) do
                            if playerId ~= VanHolder then
                                PlayerStreaks[playerId] = 0
                            end
                        end
                        
                        -- Save streaks after update (force save on win - critical event)
                        SaveStreaks(true)
                    end
                    
                    -- Format winner text with gang/job if available
                    local winnerText = winnerName
                    if winnerRole then
                        winnerText = string.format("%s %s", winnerName, winnerRole)
                    end
                    
                    -- Give random loot to winner using ox_inventory
                    if GetResourceState('ox_inventory') == 'started' and #Config.LOOT_POOL > 0 then
                        -- Process each item in the loot pool
                        for _, loot in ipairs(Config.LOOT_POOL) do
                            if loot.item and loot.minCount and loot.maxCount then
                                -- Validate counts
                                local minCount = math.max(1, loot.minCount or 1)
                                local maxCount = math.max(minCount, loot.maxCount or minCount)
                                -- Validate chance (default to 100 if not specified)
                                local chance = math.max(0, math.min(100, loot.chance or 100))
                                -- Validate minItems/maxItems (default to 1 if not specified)
                                local minItems = math.max(0, loot.minItems or 1)
                                local maxItems = math.max(minItems, loot.maxItems or minItems)
                                
                                -- Determine how many times to try giving this item
                                local itemsToGive = math.random(minItems, maxItems)
                                
                                -- Try to give the item the specified number of times
                                for i = 1, itemsToGive do
                                    -- Roll for chance (0-100)
                                    local roll = math.random(1, 100)
                                    
                                    -- Only give item if chance roll passes
                                    if roll <= chance then
                                        -- Randomize the count for this item based on its min/max
                                        local randomCount = math.random(minCount, maxCount)
                                        
                                        -- Give the item to the winner with random count
                                        exports.ox_inventory:AddItem(VanHolder, loot.item, randomCount)
                                    end
                                end
                            end
                        end
                    end
                    
                    -- Streak System: Give bonus rewards for consecutive wins
                    if Config.STREAK_ENABLED and currentStreak > 1 and Config.STREAK_BONUS_LOOT and #Config.STREAK_BONUS_LOOT > 0 then
                        local streakRewardGiven = false
                        for _, streakReward in ipairs(Config.STREAK_BONUS_LOOT) do
                            if currentStreak >= streakReward.streak then
                                -- Give bonus items for this streak level
                                if streakReward.items and #streakReward.items > 0 then
                                    for _, bonusItem in ipairs(streakReward.items) do
                                        if bonusItem.item and bonusItem.minCount and bonusItem.maxCount then
                                            local minCount = math.max(1, bonusItem.minCount or 1)
                                            local maxCount = math.max(minCount, bonusItem.maxCount or minCount)
                                            local chance = math.max(0, math.min(100, bonusItem.chance or 100))
                                            
                                            local roll = math.random(1, 100)
                                            if roll <= chance then
                                                local randomCount = math.random(minCount, maxCount)
                                                exports.ox_inventory:AddItem(VanHolder, bonusItem.item, randomCount)
                                                streakRewardGiven = true
                                            end
                                        end
                                    end
                                end
                            end
                        end
                        
                        if streakRewardGiven then
                            TriggerClientEvent('chat:addMessage', VanHolder, {
                                color = {255, 215, 0},
                                args = {"ASTRAL VAN HOLDS", string.format("🔥 STREAK BONUS! %d consecutive wins! Bonus rewards added! 🔥", currentStreak)}
                            })
                        end
                    end
                    
                    -- Announce winner to all players with improved message
                    local holdTimeMinutes = math.floor(HoldTime / 60)
                    local holdTimeSeconds = HoldTime % 60
                    local timeText = string.format("%dm %ds", holdTimeMinutes, holdTimeSeconds)
                    
                    local chatMessage = string.format("^2%s^7 has won the Van Hold event! (Held for %s)", winnerText, timeText)
                    if winnerTeam and winnerTeam ~= "Unknown" then
                        chatMessage = string.format("^2%s^7 (%s) has won the Van Hold event! (Held for %s)", winnerText, winnerTeam, timeText)
                    end
                    
                    -- Add streak info to announcement if streak is active
                    if Config.STREAK_ENABLED and currentStreak > 1 then
                        chatMessage = chatMessage .. string.format(" 🔥 %d WIN STREAK! 🔥", currentStreak)
                    end
                    
                    TriggerClientEvent('chat:addMessage', -1, {
                        color = {100, 150, 255},
                        multiline = true,
                        args = {"ASTRAL VAN HOLDS", chatMessage}
                    })
                    
                    TriggerClientEvent('van:declareWinner', -1, VanHolder, HolderTeam, winnerRole)
                        TriggerClientEvent('van:cleanup', -1)
                    end
                end
            end
            -- If no holder, still send timer updates (timer pauses but doesn't reset)
            if not VanHolder then
                TriggerClientEvent('van:updateTimer', -1, HoldTime)
            end
        end
    end
end)

-- =====================
-- Auto-Spawn Timer
-- =====================

CreateThread(function()
    -- Wait a moment for config to load
    Wait(5000)
    
    if not Config or not Config.AUTO_SPAWN_ENABLED then
        return -- Exit if auto-spawn is disabled or config not loaded
    end
    
    -- Convert minutes to milliseconds (1 minute = 60000 ms)
    local intervalMs = (Config.AUTO_SPAWN_INTERVAL or 60) * 60000
    
    -- Wait a short time on server start before first spawn (30 seconds)
    Wait(30000)
    
    while true do
        -- Only start if no event is active
        if not EventActive then
            -- Pre-event announcements
            if Config.PRE_EVENT_ANNOUNCEMENT and Config.ANNOUNCEMENT_TIME and Config.ANNOUNCEMENT_TIME > 0 then
                local announcementStart = GetGameTimer()
                local announcementTimeMs = (Config.ANNOUNCEMENT_TIME or 5) * 60000
                local timeUntilEvent = intervalMs
                
                -- Announce at different intervals
                while GetGameTimer() - announcementStart < intervalMs and not EventActive do
                    local timeRemaining = intervalMs - (GetGameTimer() - announcementStart)
                    local minutesRemaining = math.floor(timeRemaining / 60000)
                    local secondsRemaining = math.floor((timeRemaining % 60000) / 1000)
                    
                    -- Announce at 5 min, 3 min, 1 min, 30 sec, 10 sec
                    if timeRemaining <= 300000 and timeRemaining > 299000 then -- 5 minutes
                        TriggerClientEvent('chat:addMessage', -1, {
                            color = {100, 150, 255},
                            args = {"ASTRAL VAN HOLDS", "Van Hold event starting in 5 minutes!"}
                        })
                        TriggerClientEvent('van:preEventAnnouncement', -1, 5, "minutes")
                    elseif timeRemaining <= 180000 and timeRemaining > 179000 then -- 3 minutes
                        TriggerClientEvent('chat:addMessage', -1, {
                            color = {100, 150, 255},
                            args = {"ASTRAL VAN HOLDS", "Van Hold event starting in 3 minutes!"}
                        })
                        TriggerClientEvent('van:preEventAnnouncement', -1, 3, "minutes")
                    elseif timeRemaining <= 60000 and timeRemaining > 59000 then -- 1 minute
                        TriggerClientEvent('chat:addMessage', -1, {
                            color = {255, 165, 0},
                            args = {"ASTRAL VAN HOLDS", "Van Hold event starting in 1 minute!"}
                        })
                        TriggerClientEvent('van:preEventAnnouncement', -1, 1, "minute")
                    elseif timeRemaining <= 30000 and timeRemaining > 29000 then -- 30 seconds
                        TriggerClientEvent('chat:addMessage', -1, {
                            color = {255, 165, 0},
                            args = {"ASTRAL VAN HOLDS", "Van Hold event starting in 30 seconds!"}
                        })
                        TriggerClientEvent('van:preEventAnnouncement', -1, 30, "seconds")
                    elseif timeRemaining <= 10000 and timeRemaining > 9000 then -- 10 seconds
                        TriggerClientEvent('chat:addMessage', -1, {
                            color = {255, 0, 0},
                            args = {"ASTRAL VAN HOLDS", "Van Hold event starting in 10 seconds!"}
                        })
                        TriggerClientEvent('van:preEventAnnouncement', -1, 10, "seconds")
                    end
                    
                    Wait(1000) -- Check every second
                end
            end
            
            StartVanEvent(nil) -- nil = automatic spawn (no admin source)
        end
        
        -- Wait for the interval before next check
        Wait(intervalMs)
    end
end)
