-- =====================
-- Van Hold Event - Client
-- =====================

-- Debug helper function
local function DebugPrint(message)
    if Config and Config.DEBUG_MODE then
        print(message)
    end
end

local van = nil
local eventActive = false
local holding = false
local holder = nil
local holderTeam = nil
local holderGang = nil
local eventStartTime = 0
local eventEndTime = 0
local maxTime = 0
local wasDead = false
local notificationEndTime = 0
local winnerNotificationEndTime = 0
local winnerName = nil
local winnerTeam = nil
-- Removed countdownEndTime - instant claim
local canClaim = false
local vanLocationName = nil
local killFeedText = nil
local killFeedEndTime = 0
local currentEvent = {
    location = nil,
    blip = nil,
    radiusBlip = nil
}
local uiShown = false
local inRedzone = false
local hasBeenNotified = false

-- Cache for UI updates to prevent unnecessary NUI messages
local lastClaimerUIUpdate = { name = nil, isYou = false }
local lastTimeString = ""

-- Config
local HOLD_RADIUS = 50.0
local CLAIM_DISTANCE = 2.0 -- Distance to press E to claim the van
local PROMPT_DISTANCE = 5.0 -- Distance to show "Press E" prompt
local vanModel = `stockade`
local NOTIFICATION_DURATION = 5000 -- 5 seconds
local WINNER_NOTIFICATION_DURATION = 20000 -- 20 seconds
-- Removed countdown delay - instant claim 

local TEAM_MAP = {
    police = 'Police',
    sheriff = 'Sheriff',
    ambulance = 'EMS'
}

-- =====================
-- Utility Functions
-- =====================

-- Create blip
local function CreateRedzoneBlip()
    if not currentEvent.location then 
        DebugPrint("^1[VANHOLD DEBUG] CreateRedzoneBlip: currentEvent.location is nil^7")
        return 
    end

    if not Config or not Config.RedzoneBlip then
        DebugPrint("^1[VANHOLD DEBUG] Config.RedzoneBlip not found!^7")
        return
    end

    if currentEvent.blip then RemoveBlip(currentEvent.blip) end
    if currentEvent.radiusBlip then RemoveBlip(currentEvent.radiusBlip) end

    local coords = currentEvent.location.coords
    local radius = currentEvent.location.radius

    DebugPrint("^2[VANHOLD DEBUG] Creating blip at: " .. coords.x .. ", " .. coords.y .. ", " .. coords.z .. " | Radius: " .. radius .. "^7")

    local radiusBlip = AddBlipForRadius(coords.x, coords.y, coords.z, radius)
    SetBlipHighDetail(radiusBlip, true)
    SetBlipColour(radiusBlip, Config.RedzoneBlip.color)
    SetBlipAlpha(radiusBlip, 128)

    local blipMarker = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(blipMarker, Config.RedzoneBlip.sprite)
    SetBlipDisplay(blipMarker, 4)
    SetBlipScale(blipMarker, Config.RedzoneBlip.scale)
    SetBlipColour(blipMarker, Config.RedzoneBlip.color)
    SetBlipAsShortRange(blipMarker, false)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("VANHOLD - " .. currentEvent.location.name)
    EndTextCommandSetBlipName(blipMarker)

    currentEvent.blip = blipMarker
    currentEvent.radiusBlip = radiusBlip

    DebugPrint("^2[VANHOLD DEBUG] Blip created! Blip ID: " .. tostring(blipMarker) .. " | Radius Blip ID: " .. tostring(radiusBlip) .. "^7")
end

-- Remove event entity
local function RemoveEventEntity()
    if currentEvent.blip then
        RemoveBlip(currentEvent.blip)
        currentEvent.blip = nil
    end

    if currentEvent.radiusBlip then
        RemoveBlip(currentEvent.radiusBlip)
        currentEvent.radiusBlip = nil
    end

    currentEvent.location = nil
end

-- Check if player is in redzone (optimized with squared distance)
local function IsInRedzone()
    if not currentEvent.location then return false end
    local playerCoords = GetEntityCoords(PlayerPedId())
    local coords = currentEvent.location.coords
    local dx = playerCoords.x - coords.x
    local dy = playerCoords.y - coords.y
    local dz = playerCoords.z - coords.z
    local distanceSq = (dx * dx) + (dy * dy) + (dz * dz)
    local radiusSq = currentEvent.location.radius * currentEvent.location.radius
    return distanceSq <= radiusSq
end

-- NUI Functions
local function ShowUI(locationName)
    if not uiShown and currentEvent.location then
        SendNUIMessage({
            action = 'showUI',
            locationName = locationName or currentEvent.location.name
        })
        uiShown = true
    end
end

local function HideUI()
    if uiShown then
        SendNUIMessage({ action = 'hideUI' })
        uiShown = false
    end
end

local function UpdateUITimer(timeString)
    -- Cache check to prevent redundant NUI updates
    if timeString == lastTimeString then
        return -- No change, skip update
    end
    
    lastTimeString = timeString
    
    if uiShown then
        SendNUIMessage({
            action = 'updateTimer',
            time = timeString
        })
    end
end

local function UpdateUIClaimer(claimerName, isYou)
    -- Cache check to prevent redundant NUI updates
    local name = claimerName or ''
    local you = isYou or false
    
    if lastClaimerUIUpdate.name == name and lastClaimerUIUpdate.isYou == you then
        return -- No change, skip update
    end
    
    lastClaimerUIUpdate.name = name
    lastClaimerUIUpdate.isYou = you
    
    -- Always show UI if there's a claimer and we're in redzone
    if claimerName and claimerName ~= '' and inRedzone and not uiShown then
        ShowUI(vanLocationName)
    end
    
    if uiShown then
        SendNUIMessage({
            action = 'updateClaimer',
            claimer = name,
            isYou = you
        })
    end
end

-- =====================
-- Event Handlers
-- =====================

RegisterNetEvent('van:eventStarted', function(eventDuration, locationName, totalEvents)
    eventActive = true
    maxTime = eventDuration -- Event duration in seconds (for countdown timer)
    eventStartTime = GetGameTimer()
    eventEndTime = eventStartTime + (eventDuration * 1000) -- Convert to milliseconds
    holder = nil
    holderTeam = nil
    holderGang = nil
    canClaim = true -- Instant claim (no countdown delay)
    vanLocationName = locationName
    
    -- Clear UI caches for new event
    lastClaimerUIUpdate = { name = nil, isYou = false }
    lastTimeString = ""
    inRedzone = false
    hasBeenNotified = false
    
    -- Don't show UI here - it will be shown when player enters redzone
    
    -- Show improved notification with more details
    local durationMinutes = math.floor(eventDuration / 60)
    local notificationText = string.format('VAN HOLD EVENT STARTED\nLocation: %s\nDuration: %d minutes\nEvent #%d', 
        locationName or "Unknown", 
        durationMinutes,
        totalEvents or 0
    )
    lib.notify({
        title = 'ASTRAL VAN HOLDS',
        description = notificationText,
        type = 'inform',
        duration = NOTIFICATION_DURATION
    })
    
    -- Play sound effect
    PlaySoundFrontend(-1, "Mission_Pass_Notify", "DLC_HEISTS_GENERAL_FRONTEND_SOUNDS", true)
end)

RegisterNetEvent('van:eventStopped', function()
    eventActive = false
    holder = nil
    holderTeam = nil
    holderGang = nil
    winnerName = nil
    winnerTeam = nil
    if holding then
        holding = false
        TriggerServerEvent('van:clearHolder')
    end
    HideUI()
    RemoveEventEntity()
    
    -- Clear UI caches and redzone state
    lastClaimerUIUpdate = { name = nil, isYou = false }
    lastTimeString = ""
    inRedzone = false
    hasBeenNotified = false
    canClaim = false
    countdownEndTime = 0
    vanLocationName = nil
end)

RegisterNetEvent('van:spawn', function(x, y, z, heading, locationName, spawnerId)
    vanLocationName = locationName
    local myPlayerId = GetPlayerServerId(PlayerId())
    local isSpawner = (spawnerId and tonumber(spawnerId) == myPlayerId)
    
    -- Store location data for redzone blip
    local blipRadius = Config.RedzoneBlip and Config.RedzoneBlip.radius or 250.0
    currentEvent.location = {
        coords = vector3(x, y, z),
        radius = blipRadius,
        name = locationName
    }
    
    -- Create redzone blip immediately when location is known
    CreateRedzoneBlip()
    
    -- Delete existing van if it exists
    if van and DoesEntityExist(van) then
        DeleteEntity(van)
        van = nil
    end
    
    local coords = vector3(x, y, z)
    heading = heading or 0.0

    RequestModel(vanModel)
    while not HasModelLoaded(vanModel) do Wait(0) end

    -- Only spawner creates the van, others wait and find it
    if isSpawner then
        -- Spawner creates the van immediately
        van = CreateVehicle(vanModel, coords.x, coords.y, coords.z, heading, true, true)
        DebugPrint("^2[VANHOLD] Spawner created van: " .. tostring(van) .. "^7")
    else
        -- Non-spawners wait for spawner to create it, then find it
        Wait(1500)
        local attempts = 0
        while not van and attempts < 10 do
            local nearbyVan = GetClosestVehicle(coords.x, coords.y, coords.z, 50.0, 0, 71)
            if nearbyVan and nearbyVan ~= 0 and DoesEntityExist(nearbyVan) then
                local model = GetEntityModel(nearbyVan)
                if model == vanModel then
                    van = nearbyVan
                    DebugPrint("^2[VANHOLD] Found van: " .. tostring(van) .. "^7")
                    break
                end
            end
            attempts = attempts + 1
            Wait(500)
        end
        
        if not van then
            DebugPrint("^1[VANHOLD] WARNING: Could not find van!^7")
        end
    end
    
    -- Set van properties (only if van exists)
    if van and DoesEntityExist(van) then
        SetEntityInvincible(van, true)
        SetVehicleCanBeVisiblyDamaged(van, false)
        SetEntityAsMissionEntity(van, true, true)
        
        -- Network the vehicle properly
        local netId = NetworkGetNetworkIdFromEntity(van)
        SetNetworkIdCanMigrate(netId, false)
        NetworkRegisterEntityAsNetworked(van)
        
        DebugPrint("^2[VANHOLD] Van properties set successfully^7")
    else
        DebugPrint("^1[VANHOLD] ERROR: Van does not exist after spawn!^7")
    end

    -- Wait a frame to ensure vehicle is fully created
    Wait(200)
end)

RegisterNetEvent('van:updateHolder', function(id, team, gang)
    local previousHolder = holder
    local myPlayerId = GetPlayerServerId(PlayerId())
    local wasHolding = (holder == myPlayerId)
    holder = id
    holderTeam = team
    holderGang = gang
    
    -- Clear holding flag if someone else took over (or if holder was cleared)
    if id ~= myPlayerId then
        holding = false
        -- If you were holding and someone else took over, show notification
        if wasHolding and id and id ~= nil then
            local newHolderName = GetPlayerName(GetPlayerFromServerId(id)) or "Unknown"
            lib.notify({
                title = 'Claim Lost',
                description = newHolderName .. ' has taken over the van!',
                type = 'error',
                duration = 5000
            })
        end
    end
    
    -- Update NUI claimer
    if id then
        local holderName = GetPlayerName(GetPlayerFromServerId(id)) or "Unknown"
        local isYou = (id == myPlayerId)
        UpdateUIClaimer(holderName, isYou)
    else
        UpdateUIClaimer("", false)
        holding = false -- Clear holding if holder was cleared
    end
    
    -- Play sound when someone takes the van
    if id and id ~= previousHolder then
        PlaySoundFrontend(-1, "CHECKPOINT_PERFECT", "HUD_MINI_GAME_SOUNDSET", true)
        
        -- Show notification if you're not the holder
        if id ~= myPlayerId then
            local holderName = GetPlayerName(GetPlayerFromServerId(id)) or "Unknown"
            lib.notify({
                title = 'ASTRAL VAN HOLDS',
                description = string.format('%s has claimed the van!', holderName),
                type = 'inform',
                duration = 3000
            })
        end
    end
end)

local lastLowTimeWarning = 0
RegisterNetEvent('van:updateTimer', function(remainingTime)
    -- remainingTime is now the countdown time in seconds 
    -- Update event end time based on remaining time
    if eventActive and remainingTime and remainingTime > 0 then
        eventEndTime = GetGameTimer() + (remainingTime * 1000)
        DebugPrint("^3[VANHOLD CLIENT] Timer updated: " .. remainingTime .. " seconds remaining^7")
    end
    
    -- Update UI timer immediately when we receive update from server
    if uiShown and remainingTime and remainingTime >= 0 then
        local minutes = math.floor(remainingTime / 60)
        local seconds = math.floor(remainingTime % 60)
        local timeString = string.format("%02d:%02d", minutes, seconds)
        UpdateUITimer(timeString)
    end
    
    -- Play warning sound when timer is running low (last 10 seconds)
    if eventActive and holder == GetPlayerServerId(PlayerId()) and remainingTime and remainingTime > 0 then
        if remainingTime <= 10 and remainingTime > 0 then
            local currentTime = GetGameTimer()
            -- Only play sound once per second to avoid spam
            if currentTime - lastLowTimeWarning > 1000 then
                PlaySoundFrontend(-1, "TIMER_STOP", "HUD_MINI_GAME_SOUNDSET", true)
                lastLowTimeWarning = currentTime
                
                -- Show warning notification at 10, 5, and 1 second
                if remainingTime == 10 or remainingTime == 5 or remainingTime == 1 then
                    lib.notify({
                        title = 'ASTRAL VAN HOLDS',
                        description = string.format('WARNING: %d seconds remaining!', remainingTime),
                        type = 'error',
                        duration = 2000
                    })
                end
            end
        end
    end
end)

RegisterNetEvent('van:declareWinner', function(id, team, gang)
    eventActive = false
    if holding then
        holding = false
        TriggerServerEvent('van:clearHolder')
    end
    
    PlaySoundFrontend(-1, "MP_WAVE_COMPLETE", "HUD_FRONTEND_DEFAULT_SOUNDSET", true)
    
    -- Spawn confetti at van location
    if DoesEntityExist(van) then
        CreateConfetti(van)
    end
    
    local name = GetPlayerName(GetPlayerFromServerId(id)) or "Unknown"
    winnerTeam = team
    
    -- Format winner name with gang/job if available
    if gang then
        winnerName = string.format("%s %s", name, gang)
    else
        winnerName = name
    end
    
    -- Show improved winner notification with more details
    local isWinner = (id == GetPlayerServerId(PlayerId()))
    local winnerDescription = string.format('WINNER: %s', winnerName)
    if winnerTeam and winnerTeam ~= "Unknown" then
        winnerDescription = string.format('WINNER: %s (%s)', winnerName, winnerTeam)
    end
    
    if isWinner then
        winnerDescription = winnerDescription .. '\n🎉 CONGRATULATIONS! You won! 🎉'
    end
    
    lib.notify({
        title = 'ASTRAL VAN HOLDS',
        description = winnerDescription,
        type = 'success',
        duration = WINNER_NOTIFICATION_DURATION
    })
    
    holder = nil
    holderTeam = nil
    holderGang = nil
    
    -- Note: Redzone blips will remain visible until cleanup is called
    -- This allows players to see where the event occurred
end)

RegisterNetEvent('van:cleanup', function()
    eventActive = false
    if holding then
        holding = false
        TriggerServerEvent('van:clearHolder')
    end
    
    
    if DoesEntityExist(van) then DeleteEntity(van) end
    HideUI()
    RemoveEventEntity()
    van = nil
    holder = nil
    holderTeam = nil
    holderGang = nil
    vanLocationName = nil
    canClaim = false
    countdownEndTime = 0
    holdTime = 0
    maxTime = 0
    
    -- Clear UI caches and redzone state
    lastClaimerUIUpdate = { name = nil, isYou = false }
    lastTimeString = ""
    inRedzone = false
    hasBeenNotified = false
end)

RegisterNetEvent('van:showStats', function(stats)
    -- Send stats to NUI
    SendNUIMessage({
        action = 'showStats',
        stats = stats
    })
end)

RegisterNUICallback('closeStats', function(data, cb)
    SendNUIMessage({ action = 'hideStats' })
    cb('ok')
end)

-- Leaderboard removed - stats are still tracked but no display command

RegisterNetEvent('van:killFeed', function(killerName, victimName)
    if killerName and victimName then
        killFeedText = string.format("%s killed %s (Van Holder)", killerName, victimName)
    elseif victimName then
        killFeedText = string.format("%s died (Van Holder)", victimName)
    end
    
    killFeedEndTime = GetGameTimer() + 5000 -- Show for 5 seconds
    
    -- Auto-hide kill feed
    CreateThread(function()
        Wait(5000)
        killFeedText = nil
    end)
end)

RegisterNetEvent('van:preEventAnnouncement', function(time, unit)
    local announcementText = string.format("Van Hold starting in %d %s!", time, unit)
    lib.notify({
        title = 'ASTRAL VAN HOLDS',
        description = announcementText,
        type = 'inform',
        duration = 5000
    })
end)

-- =====================
-- Death Detection
-- =====================

CreateThread(function()
    while true do
        Wait(0)
        local ped = PlayerPedId()
        local isDead = IsEntityDead(ped) or IsPedDeadOrDying(ped, true) or GetEntityHealth(ped) <= 0
        
            if isDead and not wasDead then
                wasDead = true
                if holding then
                    holding = false
                    TriggerServerEvent('van:clearHolder')
                end
            -- Try to get killer information
            local killerPed = GetPedSourceOfDeath(ped)
            local killerId = nil
            
            if killerPed and killerPed ~= 0 then
                -- Try to find the player who owns this ped
                for _, playerId in ipairs(GetActivePlayers()) do
                    if GetPlayerPed(playerId) == killerPed then
                        killerId = GetPlayerServerId(playerId)
                        break
                    end
                end
            end
            
            TriggerServerEvent('playerDied', killerId)
        elseif not isDead and wasDead then
            wasDead = false
            TriggerServerEvent('playerRespawned')
        end
    end
end)

-- =====================
-- Hold Logic
-- =====================

function ClaimVan()
    if not eventActive then
        lib.notify({
            title = 'Error',
            description = 'No active event!',
            type = 'error',
            duration = 3000
        })
        return
    end
    
    -- Note: We don't require van to exist since we're using redzone checks
    -- The van is just a visual marker, the claim is based on redzone location
    
    local ped = PlayerPedId()
    
    -- Comprehensive death check (from working script)
    local health = GetEntityHealth(ped)
    local wasabiDead = false
    
    pcall(function()
        wasabiDead = exports.wasabi_ambulance:isPlayerDead()
    end)
    
    local isDead = IsPedDeadOrDying(ped, true) or 
                  IsPedFatallyInjured(ped) or 
                  health <= 100 or
                  wasabiDead
    
    if isDead then
        lib.notify({
            title = 'Error',
            description = 'You cannot claim the van while dead!',
            type = 'error'
        })
        return
    end
    
    if not canClaim then
        lib.notify({
            title = 'Error',
            description = 'Claiming is not available yet!',
            type = 'error',
            duration = 3000
        })
        return
    end
    
    -- Check if within 2 meters of van (must be close to claim)
    local pedCoords = GetEntityCoords(ped)
    local vanCoords = DoesEntityExist(van) and GetEntityCoords(van) or nil
    
    if not vanCoords then
        lib.notify({
            title = 'Error',
            description = 'Van not found!',
            type = 'error',
            duration = 3000
        })
        return
    end
    
    local dist = #(pedCoords - vanCoords)
    DebugPrint("^3[VANHOLD CLIENT] Distance to van: " .. string.format("%.2f", dist) .. "m^7")
    
    if dist > CLAIM_DISTANCE then
        DebugPrint("^1[VANHOLD CLIENT] Too far from van: " .. string.format("%.2f", dist) .. "m (max: 2.0m)^7")
        lib.notify({
            title = 'Error',
            description = 'You must be within 2 meters of the van to claim it!',
            type = 'error',
            duration = 3000
        })
        return
    end
    
    DebugPrint("^2[VANHOLD CLIENT] Distance check passed, sending claim request to server^7")
    
    -- All checks passed - claim the van
    if not holding then
        holding = true
        local team = GetPlayerTeam()
        DebugPrint("^2[VANHOLD CLIENT] ========== SENDING CLAIM REQUEST ==========^7")
        DebugPrint("^2[VANHOLD] Attempting to claim van... Team: " .. tostring(team) .. " | Distance: " .. string.format("%.2f", dist) .. "m^7")
        DebugPrint("^2[VANHOLD] Event active: " .. tostring(eventActive) .. " | Can claim: " .. tostring(canClaim) .. "^7")
        DebugPrint("^2[VANHOLD] Triggering server event 'van:setHolder' with team: " .. tostring(team) .. "^7")
        TriggerServerEvent('van:setHolder', team, true)
        DebugPrint("^2[VANHOLD] Server event triggered^7")
    else
        DebugPrint("^3[VANHOLD] Already holding van^7")
    end
end

-- E Key Detection and UI
CreateThread(function()
    while true do
        Wait(0)
        
        if eventActive and canClaim and DoesEntityExist(van) then
            local ped = PlayerPedId()
            local isDead = IsEntityDead(ped) or IsPedDeadOrDying(ped, true) or GetEntityHealth(ped) <= 0
            
            if not isDead and not wasDead and not holding then
                local pedCoords = GetEntityCoords(ped)
                local vanCoords = GetEntityCoords(van)
                local dist = #(pedCoords - vanCoords)
                
                -- Show prompt when within 2 meters of van
                if dist <= CLAIM_DISTANCE then
                    DrawText2D(0.5, 0.85, "Press [E] to Claim The Van", true, 0.5)
                    
                    -- Check for E key press (only works within 2m of van)
                    if IsControlJustPressed(0, 38) then -- E key
                    -- Comprehensive death check (from working script)
                    local ped = PlayerPedId()
                    local health = GetEntityHealth(ped)
                    local wasabiDead = false
                    
                    pcall(function()
                        wasabiDead = exports.wasabi_ambulance:isPlayerDead()
                    end)
                    
                    local isDead = IsPedDeadOrDying(ped, true) or 
                                  IsPedFatallyInjured(ped) or 
                                  health <= 100 or
                                  wasabiDead
                    
                    if isDead then
                        lib.notify({
                            title = 'Error',
                            description = 'You cannot claim the van while dead!',
                            type = 'error'
                        })
                    else
                        ClaimVan()
                    end
                    end -- Close IsControlJustPressed check
                end -- Close IsInRedzone check
            end
        end
    end
end)

CreateThread(function()
    while true do
        local sleep = 1000
        
        if eventActive then
            -- Check if in redzone
            local wasInRedzone = inRedzone
            inRedzone = IsInRedzone()
            
            if inRedzone and not wasInRedzone and not hasBeenNotified then
                ShowUI(vanLocationName)
                lib.notify({
                    title = 'REDZONE WARNING',
                    description = 'You have entered the redzone!',
                    type = 'error',
                    duration = 5000
                })
                hasBeenNotified = true
            elseif not inRedzone and wasInRedzone then
                HideUI()
                hasBeenNotified = false
                
                -- Clear UI caches when leaving zone
                lastClaimerUIUpdate = { name = nil, isYou = false }
                lastTimeString = ""
            end
        end
        
        if not eventActive or not DoesEntityExist(van) then
            if holding then
                holding = false
                TriggerServerEvent('van:clearHolder')
            end
            Wait(sleep)
            goto continue
        end

        local ped = PlayerPedId()
        local isDead = IsEntityDead(ped) or IsPedDeadOrDying(ped, true) or GetEntityHealth(ped) <= 0
        
        if isDead or wasDead then
            if holding then
                holding = false
                TriggerServerEvent('van:clearHolder')
            end
            Wait(sleep)
            goto continue
        end

        -- Check if player is still within hold radius of van (if holding, clear if too far)
        if holding then
            if DoesEntityExist(van) then
                local pedCoords = GetEntityCoords(ped)
                local vanCoords = GetEntityCoords(van)
                local dist = #(pedCoords - vanCoords)
                
                if dist > HOLD_RADIUS then
                    holding = false
                    TriggerServerEvent('van:clearHolder')
                    lib.notify({
                        title = 'Claim Lost',
                        description = 'You left the van radius and lost the claim!',
                        type = 'error',
                        duration = 3000
                    })
                end
            else
                -- Van doesn't exist, clear hold
                holding = false
                TriggerServerEvent('van:clearHolder')
            end
        end

        Wait(sleep)
        ::continue::
    end
end)

-- Thread to update UI with timer (countdown from event duration)
CreateThread(function()
    while true do
        if eventActive and uiShown and eventEndTime > 0 then
            -- Calculate remaining time (countdown from event duration)
            local currentTime = GetGameTimer()
            local remainingTime = math.max(0, (eventEndTime - currentTime) / 1000) -- Convert to seconds
            local minutes = math.floor(remainingTime / 60)
            local seconds = math.floor(remainingTime % 60)
            local timeString = string.format("%02d:%02d", minutes, seconds)
            
            -- Only update if time actually changed (cached in UpdateUITimer)
            UpdateUITimer(timeString)

            Wait(500)
        else
            Wait(1000)
            lastTimeString = "" -- Clear cache when not active
        end
    end
end)

-- =====================
-- Leaderboard menu handler
-- Leaderboard menu removed

-- =====================
-- UI Rendering (ox_lib Style)
-- =====================

-- Countdown display removed but claiming restriction remains active
-- Players still cannot claim until countdownEndTime is reached

-- =====================
-- Utility Functions
-- =====================

function GetPlayerTeam()
    -- Check for QBCore gang
    if LocalPlayer.state.gang then
        return LocalPlayer.state.gang.name or 'Unknown'
    end
    
    -- Check for QBCore job
    if LocalPlayer.state.job then
        return TEAM_MAP[LocalPlayer.state.job.name] or 'Unknown'
    end
    
    return 'Unknown'
end

function DrawText2D(x, y, text, centered, scale)
    scale = scale or 0.42
    SetTextFont(4)
    SetTextScale(scale, scale)
    SetTextColour(255, 255, 255, 255) -- Clean white text like ox_lib
    SetTextCentre(centered or false)
    SetTextOutline()
    BeginTextCommandDisplayText("STRING")
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(x, y)
end

function CreateConfetti(entity)
    if not DoesEntityExist(entity) then return end
    
    local coords = GetEntityCoords(entity)
    local height = coords.z + 5.0
    
    -- Request particle effects
    RequestNamedPtfxAsset("scr_xs_celebration")
    while not HasNamedPtfxAssetLoaded("scr_xs_celebration") do
        Wait(10)
    end
    
    -- Create multiple confetti bursts
    CreateThread(function()
        for i = 1, 10 do
            Wait(200) -- Stagger the bursts
            
            -- Spawn confetti at different positions around the van
            local offsetX = (math.random() - 0.5) * 3.0
            local offsetY = (math.random() - 0.5) * 3.0
            local confettiCoords = vector3(coords.x + offsetX, coords.y + offsetY, height)
            
            -- Use confetti particle effect
            UseParticleFxNextCall("scr_xs_celebration")
            StartParticleFxNonLoopedAtCoord("scr_xs_confetti_burst", confettiCoords.x, confettiCoords.y, confettiCoords.z, 0.0, 0.0, 0.0, 1.0, false, false, false)
        end
        
        -- Also try alternative confetti effects
        Wait(500)
        for i = 1, 5 do
            Wait(300)
            local offsetX = (math.random() - 0.5) * 5.0
            local offsetY = (math.random() - 0.5) * 5.0
            local confettiCoords = vector3(coords.x + offsetX, coords.y + offsetY, height)
            
            -- Try different confetti effect
            UseParticleFxNextCall("scr_xs_celebration")
            StartParticleFxNonLoopedAtCoord("scr_xs_money_rain", confettiCoords.x, confettiCoords.y, confettiCoords.z, 0.0, 0.0, 0.0, 0.8, false, false, false)
        end
    end)
    
    -- Also add some explosion effects for visual flair (non-damaging)
    CreateThread(function()
        for i = 1, 3 do
            Wait(500)
            local offsetX = (math.random() - 0.5) * 2.0
            local offsetY = (math.random() - 0.5) * 2.0
            AddExplosion(coords.x + offsetX, coords.y + offsetY, height, 9, 0.1, true, false, false) -- Firework explosion type
        end
    end)
end

-- DrawLeaderboard function removed - now using ox_lib menu

function DrawKillFeed()
    if not killFeedText then return end
    
    local startX = 0.5
    local startY = 0.12
    local bgWidth = 0.25
    local bgHeight = 0.04
    
    -- Background
    DrawRect(startX, startY, bgWidth, bgHeight, 0, 0, 0, 200)
    
    -- Border
    local borderThickness = 0.002
    DrawRect(startX, startY - bgHeight/2 + borderThickness/2, bgWidth, borderThickness, 255, 0, 0, 255) -- Top (red)
    DrawRect(startX, startY + bgHeight/2 - borderThickness/2, bgWidth, borderThickness, 255, 0, 0, 255) -- Bottom (red)
    DrawRect(startX - bgWidth/2 + borderThickness/2, startY, borderThickness, bgHeight, 255, 0, 0, 255) -- Left (red)
    DrawRect(startX + bgWidth/2 - borderThickness/2, startY, borderThickness, bgHeight, 255, 0, 0, 255) -- Right (red)
    
    -- Kill feed text
    SetTextFont(4)
    SetTextScale(0.4, 0.4)
    SetTextColour(255, 100, 100, 255) -- Red tint
    SetTextCentre(true)
    SetTextOutline()
    BeginTextCommandDisplayText("STRING")
    AddTextComponentSubstringPlayerName(killFeedText)
    EndTextCommandDisplayText(startX, startY)
end

-- =====================
-- Cleanup Handler
-- =====================

AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end
    
    -- Clean up UI
    HideUI()
    
    -- Clean up entities and blips
    if DoesEntityExist(van) then DeleteEntity(van) end
    RemoveEventEntity()
    
    -- Clear all variables
    van = nil
    eventActive = false
    holding = false
    holder = nil
    holderTeam = nil
    holderGang = nil
    holdTime = 0
    maxTime = 0
    wasDead = false
    winnerName = nil
    winnerTeam = nil
    canClaim = false
    countdownEndTime = 0
    vanLocationName = nil
    killFeedText = nil
    killFeedEndTime = 0
    uiShown = false
    inRedzone = false
    hasBeenNotified = false
    notificationEndTime = 0
    winnerNotificationEndTime = 0
    
    -- Clear event location and blips
    currentEvent.location = nil
    currentEvent.blip = nil
    currentEvent.radiusBlip = nil
    
    -- Clear UI caches
    lastClaimerUIUpdate = { name = nil, isYou = false }
    lastTimeString = ""
end)

